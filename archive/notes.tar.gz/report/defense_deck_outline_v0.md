# 结项答辩 PPT 结构 v0

## 使用方式

这是结项 PPT 的逐页结构，不替代最终排版文件。建议控制在 8 页、约 5 分钟；每页只保留一条主信息，详细证据通过页脚文件名或现场 CLI 演示展开。

## 第 1 页：研究问题

**标题**：让大模型生成的算法代码可检查、可复现、可修补

**页面内容**：

- 直接答案的问题：结果可能能运行，但过程约束和失败原因不透明；
- 本项目目标：建立 `problem -> task card -> prompt -> run -> metrics -> conclusion` 证据链；
- 研究问题：过程证据是否改善，最终算法结果是否改变。

**讲解重点**：研究对象是模型辅助编程流程，不是泛化评价某个模型，更不是直接宣称教学效果。

## 第 2 页：总体流程和交付物

**标题**：从题目到可复查证据

**页面内容**：用一条横向流程展示：

```text
题目 -> Task Card -> prompt -> 代码 artifact -> 自检/回归
     -> 固定协议 -> outputs/metrics -> run/report
```

右侧列出结项交付：最终流程指南、题库与模板、评估证据、CLI 原型、报告和答辩材料。

**讲解重点**：一次 run 不是一段聊天文本，必须能回链到代码、输出、run 和 CSV。

## 第 3 页：两个主案例

**标题**：A1/A2 主案例已经闭环

**页面内容**：

| 案例 | 任务 | 固定检查 |
|---|---|---|
| A1 | Seam Carving | DP 边界、seam 连续性、尺寸和转置 |
| A2 | patch-group RPCA 灰度图像修复 | mask 约束、patch group、聚合、PSNR/SSIM/RSE |

页脚注明：A3 curve fitting、A4 Poisson blending 只有冻结条目，未进入正式实验。

**讲解重点**：A2 已从早期宽泛标签收束为可执行、可评分的 `rslt_inpainting(...)` 主案例。

## 第 4 页：实验对照和结果

**标题**：正确性相近，过程检查有差异

**页面内容**：

| 案例 | 模式 | correct | self-check |
|---|---|---:|---:|
| A1 | direct / plain / CoE | 4/4 / 4/4 / 4/4 | 0/4 / 4/4 / 4/4 |
| A2 | direct / plain / CoE | 5/5 / 5/5 / 5/5 | 0/5 / 5/5 / 5/5 |

底部注明：A1/A2 bug-repair 的 diagnosis、patch、regression 均为 3/3。

**讲解重点**：结构化 guidance 的稳定差异是自检和过程记录，不是当前设置下的最终正确率差异。

## 第 5 页：A2 结果质量和扩展范围

**标题**：最终恢复指标保持一致，执行链路扩展到更多 case

**页面内容**：

- fixed protocol：60 条记录，4 个 case，跨模式 PSNR/SSIM/RSE 一致；
- expanded-scope：48 条记录，16 个 image/corruption case，`output_ok=1` 为 48/48；
- fresh-generation：新 artifact 在同协议下回到同一结果。

**讲解重点**：不能把“指标一致”讲成没有价值，而要说明研究关注的另一维度是过程可复查性；也不能写成 guidance 提升了图像质量。

## 第 6 页：CLI 原型现场演示

**标题**：一条命令查看完整证据链

**页面内容**：展示终端命令：

```bash
python3 run_research_case.py --demo advisor
```

演示输出顺序：输入题目、结构化表示、prompt 选择、代表性 run、metrics 摘要。可选第二条命令：

```bash
python3 run_research_case.py --case A2 --mode plain_guidance --track bug-repair
```

**讲解重点**：这是已有研究资产的选择器和摘要器，不会在答辩现场触发新的 rerun。

## 第 7 页：边界和 pilot 决策

**标题**：哪些结论可以说，哪些不能说

**页面内容**：

- 可以说：当前协议下 runnable/correct/self-check、bug-repair 和输出稳定性；
- 谨慎说：结构化 guidance 更容易留下自检、根因和回归证据；
- 不能说：学生学习效果、认知负担下降、初学者一定能完成；
- formal pilot：内部 dry run 1 条，正式数据 0 条，因前置知识混杂风险暂缓。

**讲解重点**：主动报告零 formal participant 数据，比把非正式反馈包装成实验结果更可信。

## 第 8 页：结项成果和下一步

**标题**：第一轮研究闭环完成，后续从低前置知识任务开始

**页面内容**：

- 已交付：最终报告、流程指南、16 条题库索引、模板和 Task Card、A1/A2 证据、CLI、状态检查脚本；
- 结项前：导师审阅、图表排版、两次完整演练、最终归档；
- 结项后：低前置知识任务 -> 新可行性测试 -> 再考虑 participant study、A3/A4 和更完整原型。

**讲解重点**：不要用追加同协议 rerun 来替代 participant 数据缺口。

## 证据页脚建议

- 结果页：`metrics/a1_guidance_eval_v0.csv`、`metrics/a2_guidance_eval_v0.csv`；
- A2 质量页：`metrics/a2_recovery_perf_v0.csv`、`metrics/a2_expanded_scope_perf_v0.csv`；
- 边界页：`report/evidence_matrix_v0.md`、`report/internal_process_audit_v0.md`；
- 流程页：`report/final_workflow_guide_v0.md`；
- 现场演示：`report/defense_script_v0.md`。
