# 结项结果汇总 v0

## 口径

本页是结项报告使用的结果快照。数据以 `metrics/` CSV 为准，更新前先运行 `python3 scripts/check_research_status.py`。

## A1 guidance

| mode | guidance rows | correct=2 | self_check=2 |
|---|---:|---:|---:|
| direct_answer | 4 | 4/4 | 0/4 |
| plain_guidance | 4 | 4/4 | 4/4 |
| coe_guided | 4 | 4/4 | 4/4 |

来源：`metrics/a1_guidance_eval_v0.csv`。

## A1 bug-repair

三种模式各 3 条记录，diagnosis、patch 和 regression 均为 3/3。

来源：`metrics/a1_failure_repair_eval_v0.csv`。

## A2 guidance

| mode | guidance rows | correct=2 | self_check=2 |
|---|---:|---:|---:|
| direct_answer | 5 | 5/5 | 0/5 |
| plain_guidance | 5 | 5/5 | 5/5 |
| coe_guided | 5 | 5/5 | 5/5 |

来源：`metrics/a2_guidance_eval_v0.csv`。

## A2 recovery

- fixed protocol：60 条记录，4 个 image/corruption cases 在不同 mode 下保持同一组 PSNR/SSIM/RSE。
- expanded scope：48 条记录，16 个 image/corruption cases 全部 `output_ok=1`，不同 mode 下恢复指标一致。
- fresh generation：`run_055` 至 `run_057` 在同协议下回到同一结果。

来源：`metrics/a2_recovery_perf_v0.csv`、`metrics/a2_expanded_scope_perf_v0.csv`。

## A2 bug-repair

三种模式各 3 条记录，diagnosis、patch 和 regression 均为 3/3。

来源：`metrics/a2_failure_repair_eval_v0.csv`。

## Pilot 状态

- `internal_dry_run`：1 条。
- `formal_pilot`：0 条，当前暂缓执行。

## 结项解释

当前最稳妥的结论是：结构化 guidance 在当前 A1/A2 协议下没有削弱可运行性和正确性，并且更容易留下自检、根因解释和回归说明；在 A2 当前设置下，它没有改变最终恢复指标。当前数据不能支持学生学习效果、认知负担或初学者可用性的强结论。
