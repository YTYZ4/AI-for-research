# 结构化 guidance 研究流程指南 v0

## 1. 文档定位

本指南把仓库中已经验证过的 prompt、task card、检查清单、bug-repair 和 metrics 组织成一条可复查流程。它面向三类使用者：

- 研究者：按固定协议执行或复核一次 run；
- 教学设计者：从题库条目生成一个有明确输入、输出和检查点的任务；
- 答辩评审：从 CLI 入口查看题目、prompt、run 和指标之间的证据链。

本指南不把模型回答当作最终证据。最终证据必须同时包含可运行 artifact、检查结果、输出产物、run 文档和 metrics 记录。

## 2. 总体流程

统一流程如下：

```text
题目 / task-bank 条目
    -> Task Card
    -> 选择 prompt 模式
    -> 生成或读取代码 artifact
    -> 运行固定协议
    -> 自检与回归
    -> 保存 outputs / run / metrics
    -> 形成可复查结论
```

每一步都要留下一个可定位的文件或字段。若只有聊天文本而没有运行记录，不计为完成一次研究 run。

## 3. Step 0：确定条目和范围

先从 `report/task_bank_index_v1.md` 选择条目，并确认它属于哪一层：

1. 主案例家族：A1 Seam Carving 或 A2 `rslt_inpainting(...)`；
2. 固定协议子任务：例如 A1 width/height shrink、A2 `random_pixel@50%` 或 `text@50%`；
3. failure case：例如 A1 DP boundary、A2 missing mask constraint。

A3/A4 目前是 `entry_frozen`，只能作为后续扩展入口，不能写成已完成正式实验。

在开始前记录：`case_id`、`track`、测试图/输入、预处理、目标接口和是否偏离固定协议。偏离必须同时写进 run 文档和 metrics 的 `notes`。

## 4. Step 1：填写 Task Card

Task Card 至少包含以下内容：

| 字段 | 必须回答的问题 |
|---|---|
| 目标 | 代码需要实现什么，而不是泛泛地“完成作业” |
| 输入 | 类型、形状、数值范围和特殊语义是什么 |
| 输出 | 返回值、形状、范围以及必须保存的中间结果是什么 |
| 核心模型 | 算法中的变量、目标、不变量或约束是什么 |
| 接口 | 主函数名和最小可拆分函数是什么 |
| 常见错误 | 哪些错误最可能导致错误结果或无法运行 |
| 自检 | 每个错误如何用断言、shape 检查、对照或可视化发现 |
| 评估 | 用什么固定输入和指标判断完成 |

A1 的 Task Card 见 `task_cards/A1_seam_carving_taskcard_v1.md`；A2 的 Task Card 见 `task_cards/A2_rslt_inpainting_taskcard_v1.md`。

## 5. Step 2：选择 prompt 模式

### `direct_answer`

只提供题目和接口要求。它适合做最小 baseline，回答“模型在没有结构化过程要求时能否完成任务”。输出仍然要经过同一套运行、检查和记录。

### `plain_guidance`

提供题目、Task Card、固定协议和自检要求。它是结项演示的默认模式，信息量足够但结构简单，适合教学材料和可复查 run。

### `coe_guided`

要求 Reader、Planner、Coder、Reviewer、Experimenter 等角色依次完成任务。它适合需要完整过程记录的复现实验，但不能因为输出更长就直接认定质量更高。

模式选择只改变 guidance 条件，不改变固定输入、gold reference、评估指标和通过标准。对应模板见 `report/prompt_template_library_v1.md`。

## 6. Step 3：生成代码并完成最小可运行检查

生成的 artifact 至少要满足：

- 主接口存在，调用方式与 Task Card 一致；
- 依赖和路径可说明；
- 在固定输入上可以执行到输出；
- 输出文件、指标或 history 没有缺失；
- 代码没有用未声明的临时文件替代任务接口。

建议先跑最小 smoke test，再跑完整固定协议。首轮失败要保留失败原因和修补轮数，不要只保留最终代码。

## 7. Step 4：执行自检和固定协议

### A1 检查点

- DP 边界只访问合法父节点；
- seam 相邻行的列变化不超过 1；
- 每次删除后宽度减少 1，最终尺寸等于目标尺寸；
- 高度缩放的转置前后形状和通道约定一致；
- 输出 dtype 和数值范围合理。

固定输入和对照见 `report/a1_eval_protocol_v0.md`。至少保存宽度缩小、高度缩小以及与 crop/resize 的对比结果。

### A2 检查点

- `observed`、`mask` 和 `recovered` 形状一致；
- `mask > 0.5` 的观测像素在每轮更新后保持不变；
- patch group stack/unstack 的 shape 一致；
- aggregation 的 weight map 不出现零除和错位；
- 输出被限制在 `[0, 1]`；
- 计算 PSNR/SSIM/RSE 前原图与恢复图尺寸一致；
- `history` 至少记录一种迭代过程量。

固定输入是 `lena`、`barbara` 的灰度 256x256 图像，corruption 为 `random_pixel@50%` 和 `text@50%`，指标为 PSNR、SSIM、RSE、runtime。完整协议见 `report/a2_eval_protocol_v0.md`。

## 8. Step 5：Bug-repair 流程

每个 failure case 按下面顺序记录：

1. **症状**：运行输出或断言怎样失败；
2. **根因**：指出违反了哪个输入/输出约束或算法不变量；
3. **最小补丁**：只修复导致症状的逻辑，说明没有改变的部分；
4. **回归**：先重跑触发 case，再重跑至少一个正常 case；
5. **证据**：保存 patch、运行输出、`diagnosis_correct`、`patch_runnable` 和 `regression_pass`。

A1 的 failure case 包括 DP boundary、energy recompute、height transpose；A2 的 failure case 包括 missing mask constraint、mask polarity inverted、sparse component written back。评分字段定义见对应 `metrics/*failure_repair*codebook*`。

## 9. Step 6：记录和归档

一次完整 run 的最小归档集合：

| 资产 | 作用 |
|---|---|
| prompt_used | 固定本次 guidance 条件 |
| task card / protocol | 固定任务边界和输入条件 |
| generated solution | 支持代码复核 |
| outputs | 支持结果和可视化复核 |
| run 文档 | 记录过程、失败、修补和解释 |
| metrics CSV | 支持跨模式汇总 |

metrics 的 `run_id` 必须能回到对应 run 文档，run 文档中的 case、mode 和 protocol 必须与 CSV 一致。无法建立这种回链的记录只能作为草稿，不进入最终结果表。

## 10. 结论判定规则

使用以下三层措辞：

- **可以说**：当前协议下是否 runnable、correct、self-check 完整，bug-repair 是否诊断/修补/回归通过，输出指标是否稳定；
- **谨慎说**：结构化 guidance 更容易留下可复查的自检、根因和回归说明；这是 artifact/process 证据，不是学生学习效果证据；
- **不能说**：学生一定更容易完成、认知负担一定下降、formal participant pilot 已完成、A3/A4 已完成正式实验，或 A2 指标显著提高。

结项阶段每次更新后运行：

```bash
python3 scripts/check_research_status.py
python3 -m py_compile scripts/check_research_status.py
git diff --check
python3 run_research_case.py --list
python3 run_research_case.py --demo advisor
```

状态检查通过只说明仓库中的关键行数、字段和边界一致，不等于新增了实验数据。

## 11. 已验证的示例路径

### A1

```text
problems/a1_requirement.md
  -> task_cards/A1_seam_carving_taskcard_v1.md
  -> prompts/a1/baseline_plain_guidance_v0.md
  -> report/a1_eval_protocol_v0.md
  -> runs/2026-03-26_run_007_a1_plain_guidance_baseline.md
  -> metrics/a1_guidance_eval_v0.csv
```

### A2

```text
problems/a2_requirement.md
  -> task_cards/A2_rslt_inpainting_taskcard_v1.md
  -> prompts/a2/baseline_plain_guidance_v0.md
  -> report/a2_eval_protocol_v0.md
  -> runs/2026-04-12_run_031_a2_plain_guidance_baseline.md
  -> outputs/...
  -> metrics/a2_guidance_eval_v0.csv + metrics/a2_recovery_perf_v0.csv
```

答辩时建议使用 A2 这条路径，因为它能在一个案例中同时展示输入约束、结构化 guidance、固定协议、输出指标和结论边界。
