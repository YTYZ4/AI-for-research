# Evidence Matrix v0

## 用途

这张表把当前仓库已经有的证据、能支持的判断和不能支持的判断放在一起，作为中期报告与后续更新的统一口径。它不把同一实现的 rerun 当成新的题目，也不把内部 dry run 当成正式受试者样本。

## 主证据矩阵

| 证据层 | 数据 / 资产 | 当前结果 | 可以支持的判断 | 不能支持的判断 |
|---|---|---|---|---|
| A1 guidance | `metrics/a1_guidance_eval_v0.csv`，12 行 | 三种模式均 `correct=2` 为 4/4；direct 的 `self_check=2` 为 0/4，plain/CoE 为 4/4 | A1 固定协议下，结构化 guidance 更容易留下明确自检记录 | 不能证明结构化 guidance 普遍提高最终正确率或降低耗时 |
| A1 bug-repair | `metrics/a1_failure_repair_eval_v0.csv`，9 行 | 三种模式均 diagnosis、patch、regression 通过 3/3 | curated failure case 上，三种模式都能完成可验证修复；结构化输出更便于审查过程 | 不能证明对更大 bug 分布或初学者同样有效 |
| A2 guidance | `metrics/a2_guidance_eval_v0.csv`，15 行 | 三种模式均 `correct=2` 为 5/5；direct 的 `self_check=2` 为 0/5，plain/CoE 为 5/5 | A2 固定协议下，结构化 guidance 提升过程检查覆盖 | 不能证明结构化 guidance 提升图像恢复指标 |
| A2 fixed protocol | `metrics/a2_recovery_perf_v0.csv`，60 行 | 4 个 fixed cases 在各 mode 间保持同一组 PSNR/SSIM/RSE | 当前差异主要在过程证据，不在最终恢复指标 | 不能外推到彩图、更大图像或新的 corruption 家族 |
| A2 expanded scope | `metrics/a2_expanded_scope_perf_v0.csv`，48 行 | 16 个 image/corruption cases 全部 `output_ok=1`，跨 mode 指标一致 | 执行链路不只在最初 4 个 fixed cases 上稳定 | 不能把 16 个 case 直接等同于 16 个独立题库家族 |
| A2 fresh generation | `runs/2026-04-12_run_055` 至 `057` 及对应 metrics | 新生成 artifact 在同协议下回到同一结果 | 当前结论不只是复制旧 artifact 的结果 | 不能据此估计更大模型采样方差 |
| 内部 dry run | `pilot/dry_run_records/PILOT_20260420_000/`，1 条 | 记录链路可跑通，并发现模板操作性问题 | 表单、记录、评分和 CSV 的内部回填链路可执行 | 不能支持学生可用性、学习效果或认知负担结论 |
| 非正式可行性反馈 | `report/internal_process_audit_v0.md` | 任务对 Python、算法、图像处理和代码阅读有较高前置要求 | 正式招募存在明显前置知识混杂风险，应暂缓 | 不能当作正式 participant 样本或统计结果 |

## 当前阶段结论

当前最稳妥的研究表述是：

> 在 A1/A2 当前冻结协议与 curated failure cases 下，结构化 guidance 不削弱可运行性和任务正确性，并且更容易留下自检、根因解释和回归说明等可复查过程证据；在 A2 图像修复任务中，它没有在当前实验设置下改变最终恢复指标。正式受试者 pilot 因任务前置知识要求较高而暂缓，因此当前不对学生完成率、学习效果或认知负担作强结论。

## 更新规则

每次新增实验后，先运行：

```bash
python3 scripts/check_research_status.py
```

如果数据行数、字段或 pilot 状态发生变化，应同时更新本矩阵和对应 summary 文档，避免只改 CSV 而留下过时的数字。
