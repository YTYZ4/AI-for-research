# 结项报告提纲 v0

> 状态更新（2026-10-16）：本文件保留为 A1/A2 前期阶段资料。当前执行以[跨题型助手八周规划](modeling_assistant_plan_2026-10-16.md)和[新版交付清单](modeling_assistant_delivery_checklist_v1.md)为准；旧范围、倒排安排和完成状态不适用于新助手。

## 摘要

说明研究问题、两条流程、A1/A2 实验范围、主要结果和结论边界。摘要不要写成“证明教学效果”，而应写成“建立并评估可检查、可复现的 LLM 辅助建模与求解流程”。

## 1 研究背景与问题

### 1.1 背景

- 大模型可以生成代码，但直接答案难以检查过程。
- 教学场景需要输入输出、约束、不变量、自检和回归证据。

### 1.2 研究问题

1. 如何把题目、建模、代码生成、纠错和验证组织成可复查流程？
2. 结构化 guidance 是否改善过程证据？
3. 结构化 guidance 是否改变最终算法结果？

### 1.3 研究范围

- A1：Seam Carving。
- A2：低秩图像任务族下的灰度图像修复 `rslt_inpainting(...)`。
- A3/A4：作为后续扩展入口，不支撑主结论。

## 2 方法与系统设计

### 2.1 统一证据链

`problem/task card -> prompt -> generated solution -> output -> metrics -> run -> report`

### 2.2 三种提示模式

- `direct_answer`
- `plain_guidance`
- `coe_guided`

### 2.3 结构化检查项

- 输入、输出和接口。
- 集合、参数、变量、目标、约束或算法不变量。
- 自检、回归和结果解释。

### 2.4 评估设计

- guidance：artifact、runnable、correct、self-check。
- bug-repair：diagnosis、patch、regression。
- A2 recovery：PSNR、SSIM、RSE、runtime、output status。

## 3 A1 实验

### 3.1 任务与固定协议

引用 `task_cards/A1_seam_carving_taskcard_v1.md` 和 `report/a1_eval_protocol_v0.md`。

### 3.2 guidance 结果

引用 `metrics/a1_guidance_eval_v0.csv`：12 条记录；三种模式 correct 为 4/4；direct self-check 为 0/4，plain/CoE 为 4/4。

### 3.3 bug-repair 结果

引用 `metrics/a1_failure_repair_eval_v0.csv`：9 条记录；三种模式 diagnosis、patch、regression 均为 3/3。

### 3.4 A1 小结

三种模式均可运行并完成任务；结构化 guidance 的主要差异在过程检查和回归说明。

## 4 A2 实验

### 4.1 范围收束和固定协议

说明 A2 从早期 “SVD 图像压缩”方向收束到灰度图像修复主案例，并引用 `report/timeline_scope_alignment_2026-04-12.md`。

### 4.2 baseline、replication 与 fresh-generation

引用 `metrics/a2_guidance_eval_v0.csv` 和 `metrics/a2_recovery_perf_v0.csv`：15 条 guidance 记录、60 条固定协议恢复记录。

### 4.3 bug-repair

引用 `metrics/a2_failure_repair_eval_v0.csv`：9 条记录；三种模式 diagnosis、patch、regression 均为 3/3。

### 4.4 expanded-scope

引用 `metrics/a2_expanded_scope_perf_v0.csv`：48 条记录，16 个 image/corruption case 全部 output ok。

### 4.5 A2 结果解释

固定协议和 expanded-scope 下，不同模式的 PSNR/SSIM/RSE 保持一致。因此结构化 guidance 的主要收益是过程可检查性，不是最终图像恢复质量提升。

## 5 综合讨论

### 5.1 过程质量与最终结果的区分

说明“能得到正确结果”和“能说明为什么正确、如何检查、如何回归”是两个不同维度。

### 5.2 bug-repair 作为教学化评估

说明 curated failure case 能把根因、最小修补和回归验证变成可评分对象。

### 5.3 可迁移性

说明当前证据覆盖 A1/A2 两个主案例和 A2 扩展 case，但不能直接外推到所有课程任务。

## 6 结项成果

- 最终流程文档。
- 16 条题库索引和 A3/A4 首发条目。
- prompt、task card、检查清单、错误分类和反馈规则。
- A1/A2 metrics、run、outputs 和 bug-repair benchmark。
- CLI advisor demo。
- 状态检查脚本和证据矩阵。

## 7 局限与未完成项

- formal participant pilot 暂缓。
- 当前不能推出学生完成率、学习效果或认知负担结论。
- A3/A4 尚未进入固定协议实验。
- A2 结果限于当前灰度图像、尺寸和 corruption 设置。

## 8 结论与后续工作

结论应限定为：结构化 guidance 在当前实验范围内提升了过程证据的完整性和可复查性，同时没有改变 A2 的最终恢复指标。后续若继续，应先设计低前置知识的教学任务，再做 participant study；而不是直接把当前复杂 bug-repair 任务发给非专业参与者。
