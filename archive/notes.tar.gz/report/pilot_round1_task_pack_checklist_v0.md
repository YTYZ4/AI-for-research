# Pilot Round 1 Task Pack Checklist v0

## 目的
把首轮 pilot 每个 session 该发什么、不该发什么、结束后必须回收什么写成固定清单，避免正式执行时材料混发或泄露 scorer-only 文件。

> 当前状态：任务包已整理，但正式 pilot 暂缓。以下清单是后续恢复执行时的材料控制清单，不代表已经完成发放。

## 通用规则
- 参与者可见材料和研究者内部材料必须分开打包。
- 不向参与者暴露任何 `diagnosis.md`、`fixed_code.py`、既有 `patched_code.py`、`prompt_used.md`、`model_raw_response.md`。
- `session_record`、`scoring_sheet`、CSV 模板属于研究者侧材料，不属于 participant pack。
- `process_guided_workflow` 比 `baseline_workflow` 只多给 task card 摘要、最小 checklist 和 notes template，不多给 gold answer。
- 发放前研究者先在 participant-visible 模板里预填 `session_id`、`task_id`、`condition`、`session_stage`。
- 每个 session 建议先建独立目录，并固定使用以下落盘命名：
  - `participant_form_filled.md`
  - `participant_submission.md`
  - `participant_notes_filled.md`（仅 `process_guided_workflow`）
  - `session_record_filled.md`
  - `scoring_sheet_filled.md`
  - `src/`
- 当前预建的 formal pilot task pack 根目录：`pilot/formal_pilot_task_packs/`
- 若只看“发给参与者的版本”，直接使用：
  - `pilot/formal_pilot_task_packs/S01/`
  - `pilot/formal_pilot_task_packs/S02/`
  - `pilot/formal_pilot_task_packs/S03/`
  - `pilot/formal_pilot_task_packs/S04/`
- 当前可直接发放的汇总目录：`pilot/formal_pilot_S01-S04_task_packs/`
- 当前可交付压缩包：`pilot/formal_pilot_S01-S04_task_packs.zip`
- 发放前把 `PILOT_YYYYMMDD_00X` 中的日期替换为实际日期，并再次核对参与者编号。
- 四个 session 采用同一 AI 使用规则；本轮默认禁止外部生成式 AI。若研究设计改为允许 AI，必须统一工具、模型与使用范围，并保存对话。

## 参与者看到的直观文件名

| 文件名 | 含义 |
|---|---|
| `00_请先阅读.md` | 本人任务的操作顺序与文件说明 |
| `01_参与者问卷.md` | 前测、后测与 AI 使用记录 |
| `02_问题现象.md` | 当前错误现象和触发条件 |
| `03_任务背景说明.md` | process-guided 条件的任务背景 |
| `04_修复任务说明.md` | process-guided 条件的修复目标与约束 |
| `05_操作检查清单.md` | process-guided 条件的最小自检流程 |
| `06_过程记录表.md` | process-guided 条件的过程记录 |
| `07_code_to_fix.py` | 待修复的原始代码 |
| `08_结果提交表.md` | 诊断、最终代码路径与回归说明 |
| `09_final_submission.py` | 参与者新建的最终代码文件 |

## 研究者通用底包
每个 session 都要提前备好以下研究者侧文件：
- `pilot/pilot_session_record_template_v0.md`
- `pilot/pilot_scoring_sheet_v0.md`
- `metrics/pilot_session_log_template_v0.csv`
- `metrics/pilot_session_log_codebook_v0.md`
- 对应任务的 bug-repair protocol：
  - A1 用 `report/a1_bug_repair_protocol_v0.md`
  - A2 用 `report/a2_bug_repair_protocol_v0.md`

## DRY-01

### 参与者可见
- 若选 A1：
  - `solutions/hw1_op1/failure_cases/bug_01_dp_boundary/symptom.md`
  - `solutions/hw1_op1/failure_cases/bug_01_dp_boundary/buggy_code.py`
  - `task_cards/A1_seam_carving_taskcard_v1.md`
  - `task_cards/A1_bug_repair_taskcard_v0.md`
- 若选 A2：
  - `solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/symptom.md`
  - `solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/buggy_code.py`
  - `task_cards/A2_rslt_inpainting_taskcard_v1.md`
  - `task_cards/A2_bug_repair_taskcard_v0.md`
- 通用：
  - `pilot/pilot_participant_form_v0.md`
  - `pilot/pilot_participant_submission_template_v0.md`
  - `pilot/pilot_bug_repair_checklist_v0.md`
  - `pilot/pilot_bug_repair_notes_template_v0.md`

### 结束后必须回收
- participant form
- participant submission
- notes template
- session record
- scoring sheet
- `1` 行带 `internal_dry_run` 的 CSV 草稿
- 最终代码路径与最小验证产物路径

## S01: `T2_A1_bug_01` + `baseline_workflow`

- 预打包目录：`pilot/formal_pilot_task_packs/S01_T2_A1_bug_01_baseline_workflow/`
- 直接发给参与者的简化目录：`pilot/formal_pilot_task_packs/S01/`

### 参与者可见
- `solutions/hw1_op1/failure_cases/bug_01_dp_boundary/symptom.md`
- `solutions/hw1_op1/failure_cases/bug_01_dp_boundary/buggy_code.py`
- `pilot/pilot_participant_form_v0.md`
- `pilot/pilot_participant_submission_template_v0.md`

### 研究者内部参考
- `report/a1_bug_repair_protocol_v0.md`
- `task_cards/A1_bug_repair_taskcard_v0.md`

### 严禁暴露
- `solutions/hw1_op1/failure_cases/bug_01_dp_boundary/diagnosis.md`
- `solutions/hw1_op1/failure_cases/bug_01_dp_boundary/fixed_code.py`
- `solutions/hw1_op1/generated/run_020_bug_01_direct_answer/*`
- `solutions/hw1_op1/generated/run_021_bug_01_plain_guidance/*`
- `solutions/hw1_op1/generated/run_022_bug_01_coe_guided/*`

### 结束后必须回收
- participant form
- participant submission
- session record
- scoring sheet
- CSV 草稿
- 最终代码路径
- 最小验证或输出路径

## S02: `T2_A1_bug_01` + `process_guided_workflow`

- 预打包目录：`pilot/formal_pilot_task_packs/S02_T2_A1_bug_01_process_guided_workflow/`
- 直接发给参与者的简化目录：`pilot/formal_pilot_task_packs/S02/`

### 参与者可见
- `solutions/hw1_op1/failure_cases/bug_01_dp_boundary/symptom.md`
- `solutions/hw1_op1/failure_cases/bug_01_dp_boundary/buggy_code.py`
- `task_cards/A1_seam_carving_taskcard_v1.md`
- `task_cards/A1_bug_repair_taskcard_v0.md`
- `pilot/pilot_bug_repair_checklist_v0.md`
- `pilot/pilot_bug_repair_notes_template_v0.md`
- `pilot/pilot_participant_form_v0.md`
- `pilot/pilot_participant_submission_template_v0.md`

### 研究者内部参考
- `report/a1_bug_repair_protocol_v0.md`

### 严禁暴露
- `solutions/hw1_op1/failure_cases/bug_01_dp_boundary/diagnosis.md`
- `solutions/hw1_op1/failure_cases/bug_01_dp_boundary/fixed_code.py`
- `solutions/hw1_op1/generated/run_020_bug_01_direct_answer/*`
- `solutions/hw1_op1/generated/run_021_bug_01_plain_guidance/*`
- `solutions/hw1_op1/generated/run_022_bug_01_coe_guided/*`

### 结束后必须回收
- participant form
- participant submission
- notes template
- session record
- scoring sheet
- CSV 草稿
- 最终代码路径
- 最小验证或输出路径

## S03: `T3_A2_bug_01` + `baseline_workflow`

- 预打包目录：`pilot/formal_pilot_task_packs/S03_T3_A2_bug_01_baseline_workflow/`
- 直接发给参与者的简化目录：`pilot/formal_pilot_task_packs/S03/`

### 参与者可见
- `solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/symptom.md`
- `solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/buggy_code.py`
- `pilot/pilot_participant_form_v0.md`
- `pilot/pilot_participant_submission_template_v0.md`

### 研究者内部参考
- `report/a2_bug_repair_protocol_v0.md`
- `task_cards/A2_bug_repair_taskcard_v0.md`

### 严禁暴露
- `solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/diagnosis.md`
- `solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/fixed_code.py`
- `solutions/hw2_op2/generated/run_043_bug_01_direct_answer/*`
- `solutions/hw2_op2/generated/run_044_bug_01_plain_guidance/*`
- `solutions/hw2_op2/generated/run_045_bug_01_coe_guided/*`

### 结束后必须回收
- participant form
- participant submission
- session record
- scoring sheet
- CSV 草稿
- 最终代码路径
- 最小验证或输出路径

## S04: `T3_A2_bug_01` + `process_guided_workflow`

- 预打包目录：`pilot/formal_pilot_task_packs/S04_T3_A2_bug_01_process_guided_workflow/`
- 直接发给参与者的简化目录：`pilot/formal_pilot_task_packs/S04/`

### 参与者可见
- `solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/symptom.md`
- `solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/buggy_code.py`
- `task_cards/A2_rslt_inpainting_taskcard_v1.md`
- `task_cards/A2_bug_repair_taskcard_v0.md`
- `pilot/pilot_bug_repair_checklist_v0.md`
- `pilot/pilot_bug_repair_notes_template_v0.md`
- `pilot/pilot_participant_form_v0.md`
- `pilot/pilot_participant_submission_template_v0.md`

### 研究者内部参考
- `report/a2_bug_repair_protocol_v0.md`

### 严禁暴露
- `solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/diagnosis.md`
- `solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/fixed_code.py`
- `solutions/hw2_op2/generated/run_043_bug_01_direct_answer/*`
- `solutions/hw2_op2/generated/run_044_bug_01_plain_guidance/*`
- `solutions/hw2_op2/generated/run_045_bug_01_coe_guided/*`

### 结束后必须回收
- participant form
- participant submission
- notes template
- session record
- scoring sheet
- CSV 草稿
- 最终代码路径
- 最小验证或输出路径
