# 结构化 guidance 支持可复查算法建模与代码验证：结项报告 v0

> 状态更新（2026-10-16）：本文件保留为 A1/A2 前期阶段资料。当前执行以[跨题型助手八周规划](modeling_assistant_plan_2026-10-16.md)和[新版交付清单](modeling_assistant_delivery_checklist_v1.md)为准；旧范围、倒排安排和完成状态不适用于新助手。

## 摘要

本项目研究如何把大模型辅助的算法建模与代码生成组织成可检查、可复现的研究流程。项目没有把“模型能否给出一段代码”作为唯一目标，而是将题目、输入输出约束、算法不变量、自检、bug-repair、固定协议运行、结果指标和过程记录连接成证据链。结项阶段冻结了两个主案例：A1 Seam Carving，以及 A2 基于 patch-group RPCA 的灰度图像修复 `rslt_inpainting(...)`。

在当前冻结协议下，A1 guidance 共 12 条记录，A2 guidance 共 15 条记录。三种模式（`direct_answer`、`plain_guidance`、`coe_guided`）均达到当前记录中的 runnable 与 correct 标准；但 `self_check` 在 A1 中为 direct 0/4、plain 4/4、CoE 4/4，在 A2 中为 direct 0/5、plain 5/5、CoE 5/5。A1 和 A2 各有 3 个 curated failure cases，三种模式的 diagnosis、patch 和 regression 均为 3/3。A2 fixed protocol 共 60 条恢复指标记录，expanded-scope 共 48 条记录，当前各模式的 PSNR、SSIM 和 RSE 保持一致，说明主要差异出现在过程证据而非最终恢复指标。

因此，本项目当前最稳妥的结论是：在 A1/A2 当前任务与协议范围内，结构化 guidance 不削弱可运行性和任务正确性，并且更容易留下自检、根因解释和回归说明等可复查过程证据；在 A2 当前设置下，它没有改变最终图像恢复指标。由于当前任务同时要求 Python 调试、算法理解、图像处理和代码阅读，正式 participant pilot 暂缓，不能据此声称学生学习效果、认知负担或初学者可用性已经得到证明。

**关键词**：大语言模型；算法建模；结构化 guidance；代码验证；bug-repair；可复现性

## 1. 研究背景与问题

大模型可以快速生成算法代码，但直接答案通常把题目解释、接口约束、算法假设、测试方式和失败原因压缩在一个不可检查的输出中。在教学或研究场景中，代码“能运行”并不等于过程“可复查”：使用者还需要知道输入输出是否理解正确、关键不变量是否保持、修补是否针对根因，以及结果是否通过了独立回归。

本项目围绕三个问题展开：

1. 如何把题目、建模、代码生成、纠错和验证组织成一条可复查流程？
2. 在相同任务和固定协议下，结构化 guidance 是否增加自检和过程解释证据？
3. 结构化 guidance 是否改变最终算法结果？

项目的研究对象是“可复查的模型辅助编程流程”，而不是泛化地评价某一个模型或宣称教学效果。

## 2. 研究范围与总体设计

### 2.1 主案例

- **A1 Seam Carving**：实现基于能量图、动态规划和 seam 删除的内容感知缩放，覆盖 width shrink、height shrink 及 3 个 failure cases。
- **A2 低秩图像修复**：在 `hw2-op2/src/chapter5_rslt.py::rslt_inpainting(...)` 的范围内，使用 patch group 与 RPCA 完成灰度图像修复，覆盖 fixed protocol、bug-repair、expanded-scope 和 fresh-generation。

A2 早期曾以更宽的“SVD 图像压缩”描述出现，进入实施阶段后收束为单一、可评分的灰度图像修复接口。A3 curve fitting 和 A4 Poisson image blending 已冻结首发条目，但未进入正式固定协议实验，因而不支撑主结论。

### 2.2 统一证据链

```text
problem -> task card -> prompt -> generated solution -> output
        -> metrics -> run document -> report conclusion
```

每次 run 都要求 prompt、Task Card、protocol、代码 artifact、outputs、run 文档和 metrics 之间可以互相定位。研究仓库中 `report/final_workflow_guide_v0.md` 对这一流程给出了可直接执行的版本。

### 2.3 三种 guidance 模式

- `direct_answer`：只提供题目和接口要求，作为最小 baseline；
- `plain_guidance`：加入 Task Card、固定协议和自检要求；
- `coe_guided`：固定 Reader、Planner、Coder、Reviewer、Experimenter 等角色，要求输出完整过程记录。

三种模式使用相同的测试输入、gold reference、指标和通过标准，避免把协议变化误当成 guidance 效应。

## 3. 评估方法

### 3.1 Guidance 评估

每条 guidance 记录保存以下字段：artifact 完整性、runnable、correct、self-check、错误类型、修补轮数和首次可运行时间。这里的 `correct=2` 和 `self_check=2` 是当前仓库的通过编码，不把它们解释成连续分数或学习成绩。

### 3.2 Bug-repair 评估

每个 failure case 依次检查 diagnosis、patch runnable 和 regression pass。A1 的 failure cases 是 DP boundary、energy recompute 和 height transpose；A2 的 failure cases 是 missing mask constraint、mask polarity inverted 和 sparse component written back。每个模式在每个案例上各有一条记录。

### 3.3 A2 恢复指标

A2 fixed protocol 使用灰度 256x256 的 `lena` 和 `barbara`，corruption 为 `random_pixel@50%` 与 `text@50%`，记录 PSNR、SSIM、RSE、runtime 和 output status。expanded-scope 扩展到 16 个 image/corruption case，共 48 条 mode-case 记录。指标用于检查输出质量和执行稳定性，不把单次图像恢复质量直接等同于教学质量。

### 3.4 Pilot 边界

内部 dry run 只有 1 条记录，formal pilot 为 0 条。内部审查发现当前任务同时要求 Python 调试、算法理解、图像处理和代码阅读；若直接招募非相关背景参与者，前置知识差异会和 guidance 条件混杂。因此 formal pilot 暂缓，已有 task pack 作为候选材料保留，不把非正式反馈当作 participant 数据。

## 4. A1 结果

### 4.1 Guidance

`metrics/a1_guidance_eval_v0.csv` 共 12 条记录，每种模式 4 条。三种模式在当前记录中均 runnable 4/4、correct 4/4。过程检查差异如下：

| 模式 | 记录数 | correct=2 | self_check=2 |
|---|---:|---:|---:|
| direct_answer | 4 | 4/4 | 0/4 |
| plain_guidance | 4 | 4/4 | 4/4 |
| coe_guided | 4 | 4/4 | 4/4 |

这说明在 A1 当前固定协议下，结构化 guidance 的可观察收益主要是把输入输出约束、DP 边界、seam 连续性和尺寸检查写成明确的自检证据，而不是把三种模式的最终正确率拉开。

### 4.2 Bug-repair

`metrics/a1_failure_repair_eval_v0.csv` 共 9 条记录。三种模式各覆盖 3 个 failure cases，diagnosis、patch runnable 和 regression pass 均为 3/3。当前 curated cases 较小，不能外推到更大 bug 分布或初学者群体，但它验证了“根因—最小补丁—回归”这条记录格式可以执行。

## 5. A2 结果

### 5.1 Guidance 与固定协议

`metrics/a2_guidance_eval_v0.csv` 共 15 条记录，每种模式 5 条。三种模式均 runnable 5/5、correct 5/5；过程检查为 direct 0/5、plain 5/5、CoE 5/5。

`metrics/a2_recovery_perf_v0.csv` 共 60 条记录，覆盖 4 个 fixed cases 和 15 次 guidance run。跨模式的 PSNR、SSIM、RSE 对应相同 case 保持一致，所有记录 `output_ok=1`。这表明当前实现和固定协议已经稳定，但也意味着不能把结构化 guidance 写成“显著提高最终恢复质量”。

### 5.2 Bug-repair

`metrics/a2_failure_repair_eval_v0.csv` 共 9 条记录。三种模式在 3 个 curated failure cases 上 diagnosis、patch runnable 和 regression pass 均为 3/3。结构化 guidance 的主要作用是把 mask 约束、mask 极性、稀疏项回写等根因和回归条件显式化。

### 5.3 Expanded-scope 与 fresh-generation

`metrics/a2_expanded_scope_perf_v0.csv` 共 48 条记录，覆盖 16 个 image/corruption case，每个 case 在三种模式下都有输出，`output_ok=1` 为 48/48。对应指标在模式之间保持一致，支持“执行链路不只适用于最初 4 个 fixed cases”的有限判断，但不能把这些 case 直接当作 16 个独立教学题目。

`run_055` 至 `run_057` 保存了 fresh-generation artifact；新产物在同一协议下回到相同指标结果，说明当前结论不只是复用一份旧 artifact 的偶然结果。不过这仍然不能估计更大模型采样方差。

## 6. 综合讨论

### 6.1 结果正确性与过程可检查性是两个维度

当前数据中，三种模式在 A1/A2 主案例的 correct 通过率都很高，单看最终输出容易得出“模式没有差异”的结论。但 self-check 的编码在 direct 与结构化 guidance 之间有稳定差异；bug-repair 材料也显示结构化输出更容易留下根因、补丁范围和回归说明。因此，本项目把“得到正确结果”和“能解释为什么正确、如何检查、如何回归”分开评价。

### 6.2 Bug-repair 是可评分的过程任务

普通代码生成结果往往只留下最终版本，难以检查模型是否真正理解了错误。failure case 将症状、算法不变量和回归条件固定下来，使 diagnosis、patch 和 regression 都成为可评分字段。这是当前流程最适合教学化和复查化的部分，但 curated cases 仍然不能代表全部真实错误。

### 6.3 题库与原型的交付价值

当前题库按“主案例家族—固定协议子任务—failure cases”三层组织，共 16 个中期正式条目；A3/A4 各有一个冻结的首发条目。CLI `run_research_case.py --demo advisor` 可以把题目、结构化表示、prompt、run 和 metrics 摘要串起来，降低评审查看证据链的成本。它是已有研究资产的选择器和摘要器，不是新的模型执行器。

## 7. 结项交付物

1. **最终流程文档**：`report/final_workflow_guide_v0.md`，合并 prompt、Task Card、自检、bug-repair、固定协议和归档要求。
2. **题库与模板库**：`report/task_bank_index_v1.md`、`report/prompt_template_library_v1.md`、A1/A2 Task Card、A3/A4 冻结条目。
3. **评估证据**：A1/A2 guidance、recovery、expanded-scope、bug-repair metrics，run 文档、outputs 和 `report/evidence_matrix_v0.md`。
4. **原型**：`run_research_case.py` 的 list、case/track 查询和 advisor demo。
5. **内部审查**：`report/internal_process_audit_v0.md`，明确当前证据能支持与不能支持的判断。
6. **答辩材料**：`report/defense_script_v0.md`，包含五分钟演示顺序和常见追问口径。

## 8. 局限

- formal participant pilot 暂缓，当前没有学生完成率、学习效果或认知负担数据；
- A1/A2 样本量和 failure case 数量有限，且不少实验使用固定协议；
- A2 的结论限于当前灰度图像、尺寸和 corruption 设置，不能外推到彩图、更大图像或新的 corruption 家族；
- A3/A4 只有首发条目，没有正式固定协议结果；
- 当前 self-check 和过程证据主要由 artifact audit 评估，尚未通过独立编码者或受试者研究验证评分一致性。

## 9. 结论与后续工作

本项目已经完成从零散模型输出到可复查研究资产的第一轮闭环。基于 A1/A2 当前冻结协议，结构化 guidance 没有削弱可运行性和正确性，并且更容易产生自检、根因和回归等过程证据；在 A2 当前设置下，它没有改变最终恢复指标。这个结论的范围是“当前任务、当前协议和当前 artifact”，不是对所有学生、所有模型或所有算法任务的普遍结论。

结项后的合理延伸顺序是：先把任务改造成前置知识更低、单次时长更短的教学版本，再做新的可行性测试；之后再考虑 participant study、A3/A4 固定协议和更完整的交互式原型。结项前的工作重点应保持在报告、流程、答辩和归档 QA，不再追加同协议 rerun 来替代缺失的 participant 数据。
