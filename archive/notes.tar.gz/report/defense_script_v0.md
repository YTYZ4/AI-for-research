# 结项答辩演示脚本 v0

## 0. 演示目标

建议控制在 5 分钟，主线只展示 A2 baseline + `plain_guidance`。目标不是现场运行模型，而是让评审看到“题目 -> 结构化表示 -> prompt -> 已有 run -> metrics -> 结论边界”的完整链条。

## 1. 五分钟讲稿

### 0:00-0:40 项目问题

“本项目关注的不是大模型能不能直接写出一段代码，而是这段代码能不能被检查、复现和修补。我们把输入输出、算法不变量、自检、bug-repair、固定协议运行和 metrics 组织成一条证据链。”

### 0:40-1:20 两个主案例

“当前冻结了两个主案例。A1 是 Seam Carving，检查动态规划边界、seam 连续性和尺寸变化。A2 是基于 patch-group RPCA 的灰度图像修复，检查 mask 约束、patch group、聚合和 PSNR/SSIM/RSE。A3/A4 已有首发条目，但没有进入本次正式主实验。”

### 1:20-2:10 现场打开原型

运行：

```bash
python3 run_research_case.py --demo advisor
```

讲解：“这个入口不重新跑模型，而是从已有仓库资产中选择并摘要一条研究链。这里可以看到题目文件、Task Card、当前 prompt、代表性 run 和 metrics 摘要。”

随后可补充查询：

```bash
python3 run_research_case.py --case A2 --mode plain_guidance --track bug-repair
```

讲解：“同一个入口也能切到 failure case，查看诊断、补丁和回归证据。”

### 2:10-3:10 结果

“A1 guidance 有 12 条记录，三种模式都是 correct 4/4；但 self-check 是 direct 0/4、plain 4/4、CoE 4/4。A2 guidance 有 15 条记录，三种模式都是 correct 5/5；self-check 是 direct 0/5、plain 5/5、CoE 5/5。A1/A2 的 bug-repair 中，三种模式的 diagnosis、patch、regression 都是 3/3。”

“A2 fixed protocol 有 60 条恢复记录，expanded-scope 有 48 条记录，所有 expanded-scope 输出都成功。不同模式的 PSNR、SSIM、RSE 保持一致，所以结构化 guidance 的主要收益是过程可检查性，不是最终图像质量提升。”

### 3:10-4:00 研究判断

“因此当前能支持的判断是：在 A1/A2 当前协议下，结构化 guidance 不削弱可运行性和正确性，并且更容易留下自检、根因说明和回归说明。不能把它写成已经证明学生学习效果更好，也不能写成结构化 guidance 普遍提高算法指标。”

### 4:00-4:40 为什么没有 formal pilot

“内部 dry run 只有 1 条记录。审查发现当前任务同时要求 Python 调试、算法理解、图像处理和代码阅读。直接招募非相关背景参与者会把前置知识差异和 guidance 条件混在一起，因此 formal pilot 暂缓。任务包保留为后续候选材料，没有把非正式反馈当成 participant 数据。”

### 4:40-5:00 结项成果

“结项包包括最终流程文档、16 条题库索引、prompt 和 Task Card 模板、A1/A2 metrics 与 run、bug-repair benchmark、CLI 原型、证据矩阵和最终报告。后续如果继续，第一步应先做低前置知识的教学任务，再恢复受试者研究。”

## 2. 三个常见追问

### Q1：为什么没有 formal pilot？

答：“不是因为流程不能执行，而是当前任务对受试者要求过高。内部 dry run 已经验证记录链路可跑通，但任务同时涉及 Python、图像处理、RPCA 和代码调试。4 个 session 无法把前置知识差异与 guidance 效应分开，所以我把 pilot 明确标为暂缓，而不是把零数据包装成完成。”

### Q2：A2 最终指标没有差异，结构化 guidance 的价值是什么？

答：“在当前 fixed protocol 中，底层实现和输入协议相同，最终恢复指标一致是可以预期的。研究问题还包括过程是否可复查。self-check、根因说明和回归说明在结构化模式下更完整，因此价值体现在过程证据和复核成本，而不是当前设置下的 PSNR 提升。”

### Q3：为什么 A3/A4 没有进入正式实验？

答：“结项阶段优先保证两个主案例证据链完整。A3/A4 已经冻结 requirement、Task Card 和题库入口，但没有完成同样的固定协议、failure cases 和 metrics 链路。把它们写成已完成实验会扩大结论边界，所以只作为后续扩展入口。”

## 3. 演示前检查

```bash
python3 scripts/check_research_status.py
python3 -m py_compile scripts/check_research_status.py
git diff --check
python3 run_research_case.py --list
python3 run_research_case.py --demo advisor
```

演示时只使用仓库已有的代表性 run 和 metrics，不现场修改 CSV，不现场触发新的 rerun。
