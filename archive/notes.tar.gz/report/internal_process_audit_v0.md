# Internal Process Audit v0

## 目的

在不新增正式受试者的前提下，对现有 A1 / A2 实验产物做一次内部 artifact/process audit，回答：

1. baseline 与结构化 guidance 是否留下了不同的可复查过程证据；
2. 现有 run、metrics、bug-repair 和回归材料是否足以支持阶段性结论；
3. 哪些判断仍然不能从仓库证据推出。

这份审查不是 participant study，也不用于估计学生完成率、学习效果或认知负担。

## 审查材料

- A1 guidance：`metrics/a1_guidance_eval_v0.csv`，12 条记录
- A1 bug-repair：`metrics/a1_failure_repair_eval_v0.csv`，9 条记录
- A2 guidance：`metrics/a2_guidance_eval_v0.csv`，15 条记录
- A2 bug-repair：`metrics/a2_failure_repair_eval_v0.csv`，9 条记录
- A2 recovery：`metrics/a2_recovery_perf_v0.csv`，60 条固定协议记录
- A2 expanded-scope：`metrics/a2_expanded_scope_perf_v0.csv`，48 条记录
- 对应的 `runs/`、`outputs/`、task card、protocol 和 summary 文档

## 审查结果

### 1. 可运行性与结果正确性

- A1 guidance 记录中，三种模式均为 runnable，且 `correct=2`。
- A2 guidance 记录中，三种模式均为 runnable，且 `correct=2`。
- A1 的 3 个 curated bug 在三种模式下均完成诊断、可运行修补和回归通过。
- A2 的 3 个 curated bug 在三种模式下均完成诊断、可运行修补和回归通过。
- A2 fixed-protocol 与 expanded-scope 输出均完整，恢复指标在对应 case 上跨 mode 保持一致。

这支持“当前实验链路稳定、任务协议可执行”的判断。

### 2. 过程证据

- A1 guidance 中，`self_check=2`：
  - `direct_answer`：0/4
  - `plain_guidance`：4/4
  - `coe_guided`：4/4
- A2 guidance 中，`self_check=2`：
  - `direct_answer`：0/5
  - `plain_guidance`：5/5
  - `coe_guided`：5/5
- A1 / A2 bug-repair 材料都显示，结构化 guidance 的 reviewer / regressor / root-cause 说明更完整；direct answer 也能在当前 curated bugs 上修对，但过程记录更短。

这支持“结构化 guidance 提升自检、根因说明和回归说明的可复查性”的阶段性判断。

### 3. 最终算法指标

- A2 fixed-protocol 的 4 个 case 在 15 次 guidance run 中保持同一组 `(PSNR, SSIM, RSE)`。
- A2 expanded-scope 的 16 个 image/corruption case 在三种 mode 下也保持同一组恢复指标。

这说明当前差异主要出现在过程证据，而不是最终恢复质量。不能据此宣称结构化 guidance 显著提高图像质量或最终算法性能。

## 可支持与不可支持的结论

### 当前可以支持

- A1 / A2 主案例的实验链路已经闭环。
- 结构化 guidance 在当前任务和协议下更容易留下可检查的过程痕迹。
- curated bug-repair benchmark 可以稳定检查根因、修补和回归结果。
- 当前仓库已经具备可复查的研究资产和复现入口。

### 当前不能支持

- 学生是否更容易完成任务。
- 初学者是否能看懂代码或任务材料。
- 结构化 guidance 是否降低认知负担或提高学习效果。
- 结构化 guidance 在更大样本、更多任务或不同背景人群中是否普遍有效。

## 任务难度风险

内部 dry run 以及外部非正式反馈都指出，当前 bug-repair 任务同时要求 Python 调试、算法理解、图像处理和代码阅读能力。若直接招募非相关背景参与者，完成结果会同时受到前置知识、代码熟悉度和流程材料的影响，4 个 session 无法可靠分离这些因素。

因此，正式 pilot 当前标记为“暂缓”，而不是“已完成”或“失败”。现有 task pack 保留为后续版本候选材料。

## 下一步

1. 以本审查作为当前阶段的内部证据总结。
2. 收口中期报告、题库、prompt library、检查清单和 error taxonomy。
3. 若未来恢复 participant study，先把任务改造成更短、更独立、前置知识要求更低的教学任务，再重新做可行性测试。

## 可重复检查

当前状态可用以下只读脚本复核：

```bash
python3 scripts/check_research_status.py
```

脚本检查指标表行数、关键字段、各模式的 `correct` / `self_check`、bug-repair 的诊断与回归通过率，以及 formal pilot 是否仍为 0 条。对应的统一解释见 `report/evidence_matrix_v0.md`。

