# 结项提交清单 v0

> 状态更新（2026-10-16）：本文件保留为 A1/A2 前期阶段资料。当前执行以[跨题型助手八周规划](modeling_assistant_plan_2026-10-16.md)和[新版交付清单](modeling_assistant_delivery_checklist_v1.md)为准；旧范围、倒排安排和完成状态不适用于新助手。

## A. 最终报告

- [x] `report/final_report_v0.md` 已形成完整正文；`report/final_report_outline_v0.md` 保留为结构索引。
- [x] 摘要、研究问题、方法、A1、A2、综合讨论、局限和结论齐全。
- [ ] 每个数字都能回指 `metrics/`。
- [ ] 每个关键判断都能回指 `report/` 或 `runs/`。
- [ ] formal pilot 暂缓的原因和边界已写清楚。

## B. 最终流程与题库

- [x] `report/final_workflow_guide_v0.md`
- [ ] `report/prompt_template_library_v1.md`
- [ ] `report/structured_modeling_checklist_v1.md`
- [ ] `report/error_taxonomy_and_feedback_rules_v1.md`
- [ ] `report/task_bank_index_v1.md`
- [ ] `report/task_bank_status_v1.md`
- [ ] A1/A2 task card 和 bug-repair task card
- [ ] A3/A4 明确标为首发扩展条目，未包装成完成实验

## C. 评估证据

- [ ] A1 guidance、performance、bug-repair CSV
- [ ] A2 guidance、recovery、bug-repair、expanded-scope CSV
- [ ] A1/A2 summary 文档
- [ ] `report/evidence_matrix_v0.md`
- [ ] `report/internal_process_audit_v0.md`

## D. 原型与演示

- [ ] `python3 run_research_case.py --list`
- [ ] `python3 run_research_case.py --demo advisor`
- [x] `report/defense_script_v0.md` 5 分钟演示脚本
- [x] `report/defense_deck_outline_v0.md` 逐页 PPT 结构
- [ ] 3 个常见追问的回答：没有 formal pilot、A2 指标一致、A3/A4 未实验

## E. QA 与归档

- [x] `python3 scripts/check_research_status.py` 输出 `STATUS: PASS`
- [x] `git diff --check` 通过
- [x] README 的结项状态与报告一致
- [ ] 所有核心链接存在
- [ ] `formal_pilot` CSV 仍为 0 条，`internal_dry_run` 仅 1 条
- [ ] 不把任务包目录误写成正式实验结果
- [ ] 最终 PPT、报告、演示脚本和仓库版本号统一
