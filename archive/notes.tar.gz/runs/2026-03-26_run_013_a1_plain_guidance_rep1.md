﻿# A1 replication run 记录模板

## 元信息
- run_id：2026-03-26_run_013
- case_id：A1
- mode：plain_guidance
- replicate_id：rep1
- prompt_file：prompts/a1/baseline_plain_guidance_v0.md
- task_card_version：v1
- protocol_file：report/a1_eval_protocol_v0.md
- env：mm26

## 固定协议检查清单
- [x] 测试图片 = bing1.png, original.png
- [x] max_side = 420
- [x] 仅 shrink-only
- [x] 宽度缩小已完成
- [x] 高度缩小已完成
- [x] 对比输出已生成

## Prompt 与原始输出
- prompt_used.md： solutions/hw1_op1/generated/run_013_plain_guidance_rep1/prompt_used.md
- model_raw_response.md： solutions/hw1_op1/generated/run_013_plain_guidance_rep1/model_raw_response.md
- src 路径： solutions/hw1_op1/generated/run_013_plain_guidance_rep1/src/
- outputs 路径： outputs/hw1_op1/run_013_plain_guidance_rep1/

## 首轮评估
- artifact_complete：2
- runnable：1
- correct：2
- self_check：2
- first_error_type：none
- first_error_summary：none

## 修复记录
- fix_rounds：0
- fix_step_1：none
- fix_step_2：none
- final_working_time_min：3.6

## 待追加的 guidance 指标行
- CSV 目标： metrics/a1_guidance_eval_v0.csv
- row： 2026-03-26_run_013,A1,plain_guidance,prompts/a1/baseline_plain_guidance_v0.md,v1,2,1,2,2,none,0,3.6,replication queue item 1（复现队列项 1）

## 待追加的 codegen 性能行
- CSV 目标： metrics/a1_codegen_perf_v0.csv
- row 1： 2026-03-26_run_013,bing1.png,plain_guidance,49.7853,14.3805,66.9598,1,replication queue item 1（复现队列项 1）
- row 2： 2026-03-26_run_013,original.png,plain_guidance,96.7485,45.7774,144.9900,1,replication queue item 1（复现队列项 1）

## 备注
- 协议偏差：无
- 显著行为：首轮即可运行且完整，raw response 中包含明确的 assertion-style self checks。
- 与先前 runs 对比：运行时间显著高于 run_010 和 run_016。
