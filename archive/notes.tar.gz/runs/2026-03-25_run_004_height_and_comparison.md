# run 004 - 高度缩小与对比实验

日期：2026-03-25
阶段：加入高度缩小并生成报告对比素材

## 已实现内容
- 通过 transpose 复用 vertical seam 逻辑，实现高度缩小
- seam carving 保持 shrink-only 模式（本阶段不做放大）
- 对 GUI 目标值做 clamp，避免误触发放大请求

## 测试图片
- 主体型图片：bing1.png
- 风景细节型图片：original.png

## 生成输出
对 outputs/hw1_op1 下每个 case 文件夹：
- original.png
- resize_linear.png
- crop.png
- seam_width.png
- seam_height.png
- compare_grid.png

## 运行时间摘要
- bing1.png seam_width：17.9682 s
- bing1.png seam_height：5.0191 s
- original.png seam_width：33.6628 s
- original.png seam_height：16.9417 s

## 备注
- 为让纯 Python loop 的运行时间稳定，carving 前先把输入降采样到 max_side=420
- metrics 表已按第 6 步要求更新为统一 schema
