# run 019 - A1 bug-repair bootstrap

日期：2026-04-12
阶段：仅 bootstrap

## 目标
在不伪造实验结果的前提下，把 A1 bug-repair benchmark 补到可直接执行的状态。

## 已完成
1. 已创建 task_cards/A1_bug_repair_taskcard_v0.md
2. 已创建 report/a1_bug_repair_protocol_v0.md
3. 已创建 prompts/a1/bug_repair_direct_answer_v0.md
4. 已创建 prompts/a1/bug_repair_plain_guidance_v0.md
5. 已创建 prompts/a1/bug_repair_coe_v0.md
6. 已创建 runs/2026-04-12_a1_bug_repair_queue_v0.md
7. 已创建 runs/a1_bug_repair_run_template_v0.md
8. 已创建本 run 记录

## 边界
- 未执行 bug-repair experimental run
- 未向 metrics/a1_failure_repair_eval_v0.csv 追加行
- 本周不写最终 benchmark 结论

## 下一步
- 按 report/a1_bug_repair_protocol_v0.md 执行计划中的 9 次 bug-repair runs
- 前 3 次 runs 后，检查评分字段是否需要澄清
- 全部 9 次 runs 后，撰写 A1 bug-repair summary v0
