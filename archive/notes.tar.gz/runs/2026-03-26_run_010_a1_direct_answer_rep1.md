﻿# A1 replication run 记录模板

## 元信息
- run_id：2026-03-26_run_010
- case_id：A1
- mode：direct_answer
- replicate_id：rep1
- prompt_file：prompts/a1/baseline_direct_answer_v0.md
- task_card_version：none
- protocol_file：report/a1_eval_protocol_v0.md
- env：mm26

## 固定协议检查清单
- [x] 测试图片 = bing1.png, original.png
- [x] max_side = 420
- [x] 仅 shrink-only
- [x] 宽度缩小已完成
- [x] 高度缩小已完成
- [x] 对比输出已生成

## Prompt 与原始输出
- prompt_used.md： solutions/hw1_op1/generated/run_010_direct_answer/prompt_used.md
- model_raw_response.md： solutions/hw1_op1/generated/run_010_direct_answer/model_raw_response.md
- src 路径： solutions/hw1_op1/generated/run_010_direct_answer/src/
- outputs 路径： outputs/hw1_op1/run_010_direct_answer/

## 首轮评估
- artifact_complete：2
- runnable：1
- correct：2
- self_check：1
- first_error_type：none
- first_error_summary：none

## 修复记录
- fix_rounds：0
- fix_step_1：none
- fix_step_2：none
- final_working_time_min：1.1

## 待追加的 guidance 指标行
- CSV 目标： metrics/a1_guidance_eval_v0.csv
- row： 2026-03-26_run_010,A1,direct_answer,prompts/a1/baseline_direct_answer_v0.md,none,2,1,2,1,none,0,1.1,pilot replication 1（试点复现 1）

## 待追加的 codegen 性能行
- CSV 目标： metrics/a1_codegen_perf_v0.csv
- row 1： 2026-03-26_run_010,bing1.png,direct_answer,17.8966,5.1289,24.1589,1,pilot replication 1（试点复现 1）
- row 2： 2026-03-26_run_010,original.png,direct_answer,33.1987,17.0441,51.4347,1,pilot replication 1（试点复现 1）

## 备注
- 协议偏差：无
- 显著行为：首轮即可运行且在固定协议下完整完成。
- 与先前 runs 对比：运行时间接近 run_006 direct_answer baseline。
