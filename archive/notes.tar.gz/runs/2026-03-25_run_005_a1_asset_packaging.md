# run 005 - A1 资产整理

日期：2026-03-25
阶段：将 hw1_op1 提交整理为研究资产 A1

## 目标
把这次作业作为研究时间线里的第一个可复用资产，而不是一次性提交。

## 必要资产检查
1. task card：task_cards/A1_seam_carving_taskcard_v1.md
2. run 记录：runs/2026-03-25_run_002_template_setup.md, runs/2026-03-25_run_003_first_working_version.md, runs/2026-03-25_run_004_height_and_comparison.md
3. metrics 表：metrics/hw1_op1_metrics.csv
4. 报告草稿与最终图：report/hw1_op1_report_outline.md + outputs/hw1_op1/case_subject_bing1/compare_grid.png + outputs/hw1_op1/case_landscape_original/compare_grid.png

## 时间线对齐
- P0：第一个主案例 A1 已固定（Seam Carving）。
- W1-W3：第一张 task card、第一批 run 记录、第一张 metrics 表均已可用。
- 报告材料已可直接提交，也可在后续复用模板。

## 兜底策略
- 如果第 4 步无法运行模板：优先解决环境问题。
- 如果第 5 步长时间调试后仍无法删除一条 seam：切换到 op_2 作为兜底。
- 否则保持 op_1，避免不必要的题目切换。

## 结论
作业交付与 A1 资产初始化已经在同一条线里完成。
