# A2 bug-repair run 记录

## 元信息
- run_id：2026-04-12_run_048
- case_id：A2
- track：bug_repair
- bug_id：bug_02_mask_polarity_inverted
- mode：coe_guided
- prompt_file：prompts/a2/bug_repair_coe_v0.md
- task_card_version：A2_v1 + bug_repair_v0
- protocol_file：report/a2_bug_repair_protocol_v0.md
- env：codex_session + conda llmft，用于 regression check

## 固定材料检查清单
- [x] 已使用 symptom.md
- [x] 已使用 buggy_code.py
- [x] diagnosis.md 未提供给模型
- [x] fixed_code.py 未提供给模型
- [x] 已产出 patched code
- [x] 已完成评分

## 输入材料路径
- symptom： solutions/hw2_op2/failure_cases/bug_02_mask_polarity_inverted/symptom.md
- buggy_code： solutions/hw2_op2/failure_cases/bug_02_mask_polarity_inverted/buggy_code.py
- diagnosis_reference： solutions/hw2_op2/failure_cases/bug_02_mask_polarity_inverted/diagnosis.md
- fixed_code_reference： solutions/hw2_op2/failure_cases/bug_02_mask_polarity_inverted/fixed_code.py

## 首轮评估
- diagnosis_correct：1
- patch_runnable：1
- regression_pass：1
- first_error_summary：none

## 修复记录
- fix_rounds：0
- fix_step_1：none
- fix_step_2：none
- final_working_time_min：0.1

## 输出产物
- patched_code_path： solutions/hw2_op2/generated/run_048_bug_02_coe_guided/src/patched_code.py
- model_raw_response_path： solutions/hw2_op2/generated/run_048_bug_02_coe_guided/model_raw_response.md

## 待追加的 CSV 行
- CSV 目标： metrics/a2_failure_repair_eval_v0.csv
- row： 2026-04-12_run_048,bug_02_mask_polarity_inverted,coe_guided,1,1,1,0,0.1,首轮正确；script-assisted benchmark wall-clock

## 备注
- 协议偏差：无
- 显著行为：coe 输出最清楚地区分了 mask semantics 与 regression requirements。
- 评分依据：diagnosis 匹配 mask-polarity 参考，且 patched 行为在 llmft regression check 中匹配 fixed_code.py。
