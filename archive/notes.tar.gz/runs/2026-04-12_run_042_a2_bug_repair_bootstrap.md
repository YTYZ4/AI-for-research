# run 042 - A2 bug-repair bootstrap

日期：2026-04-12
阶段：仅 bootstrap

## 目标
在不伪造实验结果的前提下，把 A2 bug-repair benchmark 补到可直接执行的状态。

## 已完成
1. 已创建 `task_cards/A2_bug_repair_taskcard_v0.md`
2. 已创建 `report/a2_bug_repair_protocol_v0.md`
3. 已创建 `report/a2_failure_case_design_v0.md`
4. 已创建 `prompts/a2/bug_repair_direct_answer_v0.md`
5. 已创建 `prompts/a2/bug_repair_plain_guidance_v0.md`
6. 已创建 `prompts/a2/bug_repair_coe_v0.md`
7. 已创建 `metrics/a2_failure_repair_eval_v0.csv`
8. 已创建 `metrics/a2_failure_repair_eval_codebook_v0.md`
9. 已创建 `runs/2026-04-12_a2_bug_repair_queue_v0.md`
10. 已创建 `runs/a2_bug_repair_run_template_v0.md`
11. 已创建 `solutions/hw2_op2/failure_cases/`
12. 已创建本 run 记录

## 边界
- 未执行 A2 bug-repair experimental run
- 除 CSV header 外，未向 `metrics/a2_failure_repair_eval_v0.csv` 追加数据行
- 本周不写最终 benchmark 结论

## 下一步
- 按 `report/a2_bug_repair_protocol_v0.md` 执行计划中的 9 次 bug-repair runs
- 前 3 次 runs 后，检查评分字段是否需要澄清
- 全部 9 次 runs 后，撰写 `report/a2_bug_repair_summary_v0.md`
