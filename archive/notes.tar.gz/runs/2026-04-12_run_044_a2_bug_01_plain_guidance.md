# A2 bug-repair run 记录

## 元信息
- run_id：2026-04-12_run_044
- case_id：A2
- track：bug_repair
- bug_id：bug_01_missing_mask_constraint
- mode：plain_guidance
- prompt_file：prompts/a2/bug_repair_plain_guidance_v0.md
- task_card_version：A2_v1 + bug_repair_v0
- protocol_file：report/a2_bug_repair_protocol_v0.md
- env：codex_session + conda llmft，用于 regression check

## 固定材料检查清单
- [x] 已使用 symptom.md
- [x] 已使用 buggy_code.py
- [x] diagnosis.md 未提供给模型
- [x] fixed_code.py 未提供给模型
- [x] 已产出 patched code
- [x] 已完成评分

## 输入材料路径
- symptom： solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/symptom.md
- buggy_code： solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/buggy_code.py
- diagnosis_reference： solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/diagnosis.md
- fixed_code_reference： solutions/hw2_op2/failure_cases/bug_01_missing_mask_constraint/fixed_code.py

## 首轮评估
- diagnosis_correct：1
- patch_runnable：1
- regression_pass：1
- first_error_summary：none

## 修复记录
- fix_rounds：0
- fix_step_1：none
- fix_step_2：none
- final_working_time_min：0.1

## 输出产物
- patched_code_path： solutions/hw2_op2/generated/run_044_bug_01_plain_guidance/src/patched_code.py
- model_raw_response_path： solutions/hw2_op2/generated/run_044_bug_01_plain_guidance/model_raw_response.md

## 待追加的 CSV 行
- CSV 目标： metrics/a2_failure_repair_eval_v0.csv
- row： 2026-04-12_run_044,bug_01_missing_mask_constraint,plain_guidance,1,1,1,0,0.1,首轮正确；script-assisted benchmark wall-clock

## 备注
- 协议偏差：无
- 显著行为：plain guidance 明确了 observed-pixel invariant 与 patch 范围。
- 评分依据：diagnosis 匹配参考根因，且 patched 行为在 llmft regression check 中匹配 fixed_code.py。
