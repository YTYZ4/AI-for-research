# run 009 - A2 bootstrap

日期：2026-03-27
阶段：仅 bootstrap

## 目标
在不实现完整算法的前提下，建立 A2 的问题定义、任务卡和评测接入口。

## 已完成
1. 已创建 problems/a2_requirement.md
2. 已创建 task_cards/A2_taskcard_v0.md
3. 已创建本 run 记录

## 边界
- 本周不做完整 A2 implementation
- 本周不做 heavy experiment

## 下一步
- A1 direct/plain/coe baselines 完成后，开始 A2 interface-level implementation。
