# run 029 - A2 chapter5 范围配置

日期：2026-04-12
阶段：范围与 pipeline 配置

## 目标
把 A2 从 bootstrap-only 状态推进到可直接开始 baseline 实验的状态，并明确 `chapter5` 为主案例。

## 已完成
1. 已更新 `problems/a2_requirement.md`
2. 已创建 `task_cards/A2_rslt_inpainting_taskcard_v1.md`
3. 已创建 `report/a2_eval_protocol_v0.md`
4. 已创建 `prompts/a2/baseline_direct_answer_v0.md`
5. 已创建 `prompts/a2/baseline_plain_guidance_v0.md`
6. 已创建 `prompts/a2/coe_multi_role_v0.md`
7. 已创建 `metrics/a2_guidance_eval_v0.csv`
8. 已创建 `metrics/a2_guidance_eval_codebook_v0.md`
9. 已创建 `metrics/a2_recovery_perf_v0.csv`
10. 已创建 `metrics/a2_recovery_perf_codebook_v0.md`
11. 已创建 `runs/a2_guidance_run_template_v0.md`
12. 已创建 `runs/2026-04-12_a2_baseline_queue_v0.md`
13. 已创建本 run 记录

## 范围决策
- A2 gold reference = `hw2-op2/src/chapter5_rslt.py::rslt_inpainting`
- A2 不把 `hw2-op2` 的八章作为单任务
- `chapter2/3/4/8` 作为 baseline、协议参考或后续扩展

## 边界
- 本步骤未执行 A2 baseline run
- 本步骤未向 A2 metrics 追加行
- 本步骤未生成 A2 generated code

## 下一步
- 执行 A2 baseline run 1：direct_answer
- 随后在同一 fixed protocol 下执行 plain_guidance / coe_guided
