# A2 replication queue v0

## 范围
- 计划 runs：run_033 到 run_041
- 协议：`report/a2_eval_protocol_v0.md`
- 固定图片：`lena`, `barbara`
- 固定 corruption：`random_pixel@50%`, `text@50%`
- 固定图像格式：grayscale，`256x256`
- 目标函数：`rslt_inpainting(observed, mask, ...)`
- replication 含义：在同一固定 seed 与协议下重跑复制的 baseline artifacts；本 track 不重新采样 fresh model outputs

## 状态
- run_033 (direct_answer rep1)：已完成
- run_034 (plain_guidance rep1)：已完成
- run_035 (coe_guided rep1)：已完成
- run_036 (direct_answer rep2)：已完成
- run_037 (plain_guidance rep2)：已完成
- run_038 (coe_guided rep2)：已完成
- run_039 (direct_answer rep3)：已完成
- run_040 (plain_guidance rep3)：已完成
- run_041 (coe_guided rep3)：已完成
- 剩余：无

## 回填
- run 文档：9 次 run 全部完成
- `metrics/a2_guidance_eval_v0.csv`：已完成
- `metrics/a2_recovery_perf_v0.csv`：已完成
