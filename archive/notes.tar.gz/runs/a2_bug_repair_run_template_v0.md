# A2 bug-repair run 模板

## 元信息
- run_id：
- case_id：A2
- track：bug_repair
- bug_id：
- mode：
- prompt_file：
- task_card_version：
- protocol_file：report/a2_bug_repair_protocol_v0.md
- env：

## 固定材料检查清单
- [ ] 使用 symptom.md
- [ ] 使用 buggy_code.py
- [ ] diagnosis.md 不提供给模型
- [ ] fixed_code.py 不提供给模型
- [ ] 产出 patched code
- [ ] 完成评分

## 输入材料路径
- symptom：
- buggy_code：
- diagnosis_reference：
- fixed_code_reference：

## 首轮评估
- diagnosis_correct：
- patch_runnable：
- regression_pass：
- first_error_summary：

## 修复记录
- fix_rounds：
- fix_step_1：
- fix_step_2：
- final_working_time_min：

## 输出产物
- patched_code_path：
- model_raw_response_path：

## 待追加的 CSV 行
- CSV 目标： metrics/a2_failure_repair_eval_v0.csv
- row：

## 备注
- 协议偏差：
- 显著行为：
- 评分依据：
