﻿# A1 replication run 记录模板

## 元信息
- run_id：2026-03-26_run_015
- case_id：A1
- mode：plain_guidance
- replicate_id：rep3
- prompt_file：prompts/a1/baseline_plain_guidance_v0.md
- task_card_version：v1
- protocol_file：report/a1_eval_protocol_v0.md
- env：mm26

## 固定协议检查清单
- [x] 测试图片 = bing1.png, original.png
- [x] max_side = 420
- [x] 仅 shrink-only
- [x] 宽度缩小已完成
- [x] 高度缩小已完成
- [x] 对比输出已生成

## Prompt 与原始输出
- prompt_used.md： solutions/hw1_op1/generated/run_015_plain_guidance_rep3/prompt_used.md
- model_raw_response.md： solutions/hw1_op1/generated/run_015_plain_guidance_rep3/model_raw_response.md
- src 路径： solutions/hw1_op1/generated/run_015_plain_guidance_rep3/src/
- outputs 路径： outputs/hw1_op1/run_015_plain_guidance_rep3/

## 首轮评估
- artifact_complete：2
- runnable：1
- correct：2
- self_check：2
- first_error_type：none
- first_error_summary：none

## 修复记录
- fix_rounds：0
- fix_step_1：none
- fix_step_2：none
- final_working_time_min：5.5

## 待追加的 guidance 指标行
- CSV 目标： metrics/a1_guidance_eval_v0.csv
- row： 2026-03-26_run_015,A1,plain_guidance,prompts/a1/baseline_plain_guidance_v0.md,v1,2,1,2,2,none,0,5.5,replication queue item 6（复现队列项 6）

## 待追加的 codegen 性能行
- CSV 目标： metrics/a1_codegen_perf_v0.csv
- row 1： 2026-03-26_run_015,bing1.png,plain_guidance,18.8012,5.1230,24.6274,1,replication queue item 6（复现队列项 6）
- row 2： 2026-03-26_run_015,original.png,plain_guidance,35.0429,17.6436,53.6999,1,replication queue item 6（复现队列项 6）

## 备注
- 协议偏差：无
- 显著行为：首轮即可运行且在固定协议下完整完成。
- 与先前 runs 对比：运行时间明显快于 run_013 和 run_014 plain_guidance。
