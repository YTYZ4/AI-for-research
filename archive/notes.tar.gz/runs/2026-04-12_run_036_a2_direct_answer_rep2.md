# A2 replication run 记录

## 元信息
- run_id：2026-04-12_run_036
- case_id：A2
- mode：direct_answer
- replicate_id：rep2
- prompt_file：prompts/a2/baseline_direct_answer_v0.md
- task_card_version：none
- protocol_file：report/a2_eval_protocol_v0.md
- env：conda `llmft` + run-local cv2 compatibility shim

## 固定协议检查清单
- [x] 测试图片 = lena, barbara
- [x] corruption = random_pixel@50%, text@50%
- [x] 仅 grayscale
- [x] 图像尺寸 = 256x256
- [x] 固定 4 个 case 的输出已生成

## Prompt 与原始输出
- prompt_used.md： solutions/hw2_op2/generated/run_036_direct_answer_rep2/prompt_used.md
- model_raw_response.md： solutions/hw2_op2/generated/run_036_direct_answer_rep2/model_raw_response.md
- src 路径： solutions/hw2_op2/generated/run_036_direct_answer_rep2/src/
- outputs 路径： outputs/hw2_op2/run_036_direct_answer_rep2/

## 首轮评估
- artifact_complete：2
- runnable：1
- correct：2
- self_check：1
- first_error_type：none
- first_error_summary：none

## 修复记录
- fix_rounds：0
- fix_step_1：none
- fix_step_2：none
- final_working_time_min：1.1

## 待追加的 guidance 指标行
- CSV 目标： metrics/a2_guidance_eval_v0.csv
- row： 2026-04-12_run_036,A2,direct_answer,prompts/a2/baseline_direct_answer_v0.md,none,2,1,2,1,none,0,1.1,replication rep2；复用 baseline artifact；固定协议在 skimage fallback sources 下稳定

## 待追加的 recovery 性能行
- CSV 目标： metrics/a2_recovery_perf_v0.csv
- row 1： 2026-04-12_run_036,lena,random_pixel,0.5,direct_answer,15.1519,0.3766,0.3245,16.1000,1,source=skimage:astronaut
- row 2： 2026-04-12_run_036,lena,text,0.5,direct_answer,27.2597,0.9483,0.0805,16.0810,1,source=skimage:astronaut
- row 3： 2026-04-12_run_036,barbara,random_pixel,0.5,direct_answer,24.2780,0.7244,0.1358,16.6542,1,source=skimage:brick
- row 4： 2026-04-12_run_036,barbara,text,0.5,direct_answer,34.9722,0.9762,0.0397,16.3578,1,source=skimage:brick

## 备注
- 协议偏差：无；由于没有本地 data 图片，`hw2-op2/src/utils.py` 自动 fallback 到 skimage 示例图片。
- 显著行为：replication 重跑复制的 baseline artifact，并在固定 seed 下复现同一组 four-case metrics。
- 与先前 runs 对比：匹配 run_030 direct_answer baseline metrics；运行时间只在正常执行噪声内波动。
