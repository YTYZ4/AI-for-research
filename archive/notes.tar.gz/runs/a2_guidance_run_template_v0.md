# A2 guidance run 模板

## 元信息
- run_id：
- case_id：A2
- mode：
- prompt_file：
- task_card_version：
- protocol_file：report/a2_eval_protocol_v0.md
- env：

## 固定协议检查清单
- [ ] 测试图片 = lena, barbara
- [ ] corruption = random_pixel@50%, text@50%
- [ ] 仅 grayscale
- [ ] 图像尺寸 = 256x256
- [ ] 生成固定 4 个 case 的输出

## Prompt 与原始输出
- prompt_used.md：
- model_raw_response.md：
- src 路径：
- outputs 路径：

## 首轮评估
- artifact_complete：
- runnable：
- correct：
- self_check：
- first_error_type：
- first_error_summary：

## 修复记录
- fix_rounds：
- fix_step_1：
- fix_step_2：
- final_working_time_min：

## 待追加的 guidance 指标行
- CSV 目标： metrics/a2_guidance_eval_v0.csv
- row：

## 待追加的 recovery 性能行
- CSV 目标： metrics/a2_recovery_perf_v0.csv
- row 1：
- row 2：
- row 3：
- row 4：

## 备注
- 协议偏差：
- 显著行为：
- 与先前 runs 对比：
