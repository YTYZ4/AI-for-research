# A1 bug-repair run 记录

## 元信息
- run_id：2026-04-12_run_020
- case_id：A1
- track：bug_repair
- bug_id：bug_01_dp_boundary
- mode：direct_answer
- prompt_file：prompts/a1/bug_repair_direct_answer_v0.md
- task_card_version：none
- protocol_file：report/a1_bug_repair_protocol_v0.md
- env：codex_session + conda llmft，用于 regression check

## 固定材料检查清单
- [x] 已使用 symptom.md
- [x] 已使用 buggy_code.py
- [x] diagnosis.md 未提供给模型
- [x] fixed_code.py 未提供给模型
- [x] 已产出 patched code
- [x] 已完成评分

## 输入材料路径
- symptom： solutions/hw1_op1/failure_cases/bug_01_dp_boundary/symptom.md
- buggy_code： solutions/hw1_op1/failure_cases/bug_01_dp_boundary/buggy_code.py
- diagnosis_reference： solutions/hw1_op1/failure_cases/bug_01_dp_boundary/diagnosis.md
- fixed_code_reference： solutions/hw1_op1/failure_cases/bug_01_dp_boundary/fixed_code.py

## 首轮评估
- diagnosis_correct：1
- patch_runnable：1
- regression_pass：1
- first_error_summary：none

## 修复记录
- fix_rounds：0
- fix_step_1：none
- fix_step_2：none
- final_working_time_min：0.6

## 输出产物
- patched_code_path： solutions/hw1_op1/generated/run_020_bug_01_direct_answer/src/patched_code.py
- model_raw_response_path： solutions/hw1_op1/generated/run_020_bug_01_direct_answer/model_raw_response.md

## 待追加的 CSV 行
- CSV 目标： metrics/a1_failure_repair_eval_v0.csv
- row： 2026-04-12_run_020,bug_01_dp_boundary,direct_answer,1,1,1,0,0.6,首轮正确；同一会话粗略 wall-clock

## 备注
- 协议偏差：无
- 显著行为：direct answer 首轮找到 boundary-clamp 根因。
- 评分依据：diagnosis 匹配参考根因，且 patched 行为在 llmft regression check 中匹配 fixed_code.py。
