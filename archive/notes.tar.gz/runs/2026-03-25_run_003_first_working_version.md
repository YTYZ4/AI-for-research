# run 003 - 首个可运行版本（仅宽度）

日期：2026-03-25
阶段：seam carving 宽度缩小的首个最小闭环

## 目标
- 成功删除 1 条 seam
- 成功删除 10 条 seams
- 成功持续删除 seams，直到达到目标宽度

## 代码位置
- solutions/hw1_op1/reference_template/seam_carving.py
- solutions/hw1_op1/src/run_first_working_width_only.py

## 首次成功运行摘要
- 输入图片：outputs 基于 solutions/hw1_op1/figs/original.png
- 输入尺寸：(339, 510, 3)
- 输出尺寸：
  - remove_1_seam.png: (339, 509, 3)
  - remove_10_seams.png: (339, 500, 3)
  - remove_to_target_width.png: (339, 306, 3)
- 已生成必要 debug 输出：
  - energy_map.png
  - seam_overlay.png
  - remove_1_seam.png
  - remove_10_seams.png

## 错误状态
- seam carving 核心运行时崩溃：无
- 启动器临时执行问题：有
  - 问题：本终端会话中 `conda run -n mm26 ...` 返回 `CondaError: KeyboardInterrupt`
  - 修复：改用直接解释器路径 `C:\Users\ydyz0\.conda\envs\mm26\python.exe ...`
  - 结果：run 成功，输出已生成

## 调试轮次
- 第 1 轮：实现 compute energy + dp + backtrack + remove seam + loop
- 第 2 轮：加入输出导出并运行，命令包装层失败（KeyboardInterrupt）
- 第 3 轮：切换到直接的 mm26 Python 可执行文件，run 通过
- 总轮数：3

## 聚焦检查（仅 4 类常见错误）
- dp 边界越界：通过左右 clamp 和成功运行确认
- backtracking 产生非连续 seam：用断言 `abs(diff(seam)) <= 1` 检查
- 删除后的图像 shape 非法：用断言 `width decreases by 1` 检查
- 每条 seam 后忘记重算 energy：已修复为每次 loop 迭代都重新计算

## 当前结论
- 仅宽度版本的 seam carving 最小实现已经可用
- 程序在测试图片上没有崩溃
- 图像宽度已明显减少
