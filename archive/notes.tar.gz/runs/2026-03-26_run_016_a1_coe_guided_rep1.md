﻿# A1 replication run 记录模板

## 元信息
- run_id：2026-03-26_run_016
- case_id：A1
- mode：coe_guided
- replicate_id：rep1
- prompt_file：prompts/a1/coe_multi_role_v0.md
- task_card_version：v1
- protocol_file：report/a1_eval_protocol_v0.md
- env：mm26

## 固定协议检查清单
- [x] 测试图片 = bing1.png, original.png
- [x] max_side = 420
- [x] 仅 shrink-only
- [x] 宽度缩小已完成
- [x] 高度缩小已完成
- [x] 对比输出已生成

## Prompt 与原始输出
- prompt_used.md： solutions/hw1_op1/generated/run_016_coe_guided/prompt_used.md
- model_raw_response.md： solutions/hw1_op1/generated/run_016_coe_guided/model_raw_response.md
- src 路径： solutions/hw1_op1/generated/run_016_coe_guided/src/
- outputs 路径： outputs/hw1_op1/run_016_coe_guided/

## 首轮评估
- artifact_complete：2
- runnable：1
- correct：2
- self_check：2
- first_error_type：none
- first_error_summary：none

## 修复记录
- fix_rounds：0
- fix_step_1：none
- fix_step_2：none
- final_working_time_min：1.2

## 待追加的 guidance 指标行
- CSV 目标： metrics/a1_guidance_eval_v0.csv
- row： 2026-03-26_run_016,A1,coe_guided,prompts/a1/coe_multi_role_v0.md,v1,2,1,2,2,none,0,1.2,pilot replication 1（试点复现 1）

## 待追加的 codegen 性能行
- CSV 目标： metrics/a1_codegen_perf_v0.csv
- row 1： 2026-03-26_run_016,bing1.png,coe_guided,18.2013,5.1697,24.5153,1,pilot replication 1（试点复现 1）
- row 2： 2026-03-26_run_016,original.png,coe_guided,33.8726,17.2976,52.3456,1,pilot replication 1（试点复现 1）

## 备注
- 协议偏差：无
- 显著行为：model_raw_response 中有 five-role 输出，且 run 首轮即可运行。
- 与先前 runs 对比：运行时间明显低于 run_008 coe_guided，接近 run_010。
