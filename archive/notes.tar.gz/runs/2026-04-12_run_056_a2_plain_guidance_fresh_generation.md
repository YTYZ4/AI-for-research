# A2 guidance run 记录

## 元信息
- run_id：2026-04-12_run_056
- case_id：A2
- track：fresh_generation
- mode：plain_guidance
- prompt_file：prompts/a2/baseline_plain_guidance_v0.md
- task_card_version：v1
- protocol_file：report/a2_eval_protocol_v0.md
- env：conda `llmft` + run-local cv2 compatibility shim

## 固定协议检查清单
- [x] 测试图片 = lena, barbara
- [x] corruption = random_pixel@50%, text@50%
- [x] 仅 grayscale
- [x] 图像尺寸 = 256x256
- [x] 已创建 fresh generated code artifact
- [x] 固定 4 个 case 的输出已生成

## Prompt 与原始输出
- prompt_used.md： solutions/hw2_op2/generated/run_056_plain_guidance_fresh_generation/prompt_used.md
- model_raw_response.md： solutions/hw2_op2/generated/run_056_plain_guidance_fresh_generation/model_raw_response.md
- src 路径： solutions/hw2_op2/generated/run_056_plain_guidance_fresh_generation/src/
- outputs 路径： outputs/hw2_op2/run_056_plain_guidance_fresh_generation/

## 首轮评估
- artifact_complete：2
- runnable：1
- correct：2
- self_check：2
- first_error_type：none
- first_error_summary：none

## 修复记录
- fix_rounds：0
- fix_step_1：none
- fix_step_2：none
- final_working_time_min：1.4

## 待追加的 guidance 指标行
- CSV 目标： metrics/a2_guidance_eval_v0.csv
- row： 2026-04-12_run_056,A2,plain_guidance,prompts/a2/baseline_plain_guidance_v0.md,v1,2,1,2,2,none,0,1.4,首轮可运行；fresh generated artifact；固定协议已完成并使用 skimage fallback sources

## 待追加的 recovery 性能行
- CSV 目标： metrics/a2_recovery_perf_v0.csv
- row 1： 2026-04-12_run_056,lena,random_pixel,0.5,plain_guidance,15.1519,0.3766,0.3245,17.5808,1,source=skimage:astronaut
- row 2： 2026-04-12_run_056,lena,text,0.5,plain_guidance,27.2597,0.9483,0.0805,17.3101,1,source=skimage:astronaut
- row 3： 2026-04-12_run_056,barbara,random_pixel,0.5,plain_guidance,24.2780,0.7244,0.1358,17.9366,1,source=skimage:brick
- row 4： 2026-04-12_run_056,barbara,text,0.5,plain_guidance,34.9722,0.9762,0.0397,26.2246,1,source=skimage:brick

## 备注
- 协议偏差：无；由于没有本地 data 图片，`hw2-op2/src/utils.py` 自动 fallback 到 skimage 示例图片。
- 显著行为：fresh plain-guidance artifact 加入明确的 observed-pixel 与 finite-value checks，同时保持相同 recovery path。
- 解释边界：本 track 在同一 prompt family 下使用新生成的本地产物；没有复用早先的 baseline `a2_generated.py` 文件。
