# AI-for-research

**2026-10-17 当前执行重点：** 转向“同一初稿、两种反馈、独立评分”的检查机制研究，暂缓扩题和逐项补丁。生产计划小实验已完成，两组结果相同，尚无反馈增益证据。见[协议](task_cards/production_feedback_pilot_v1.md)及[报告](report/production_feedback_pilot_2026-10-17.md)。以下旧版本记录保留为历史。

本仓库记录一个大研课题：研究大模型在数学建模与求解教学中的使用方式。

项目关注点不是“模型能不能直接给答案”，而是把模型生成过程整理成可检查、可复现、可评分、可教学复用的流程：

- 题目要求先结构化
- prompt、代码、输出和评分口径分开保存
- 每次运行都有 run 文档和 metrics 行
- 固定错误能诊断、修补、回归验证
- 最后沉淀成题库、模板、原型入口和小样本试用材料

v0.11.5：否定表达与隐含冲突误接管已补修，196项测试通过；合法单位换算仍有错误拒绝，未全部解决。主批三层50/66、50/66、61/66；补批13/21、13/21、17/21，分别统计且保留全部失败。[本轮证据](report/false_interceptions_regression_2026-10-16.md)。

v0.11.6已隔离图原始输入契约，204项测试通过。定向42次回归：原始30/42、格式后30/42、本地后39/42；合法图换算21/21原始通过，仍保留3次最小费用流拒绝原因为空的失败。[证据](report/graph_contract_regression_2026-10-16.md)。

v0.11.7修复非就绪响应说明契约，210项本地测试通过。定向42次原始34/42、格式后34/42、本地后40/42；最小费用流及改写9/9有明确拒绝说明。保留2项方向追问失败（1项词法误判、1项实际状态错误），拒绝说明仍有附加断言质量问题。[证据](report/refusal_contract_regression_2026-10-16.md)。

v0.11.8修正缺方向与不支持任务的区分，并检查拒绝附加断言；当前217项测试通过。48次真实调用原冻结三层39/48、39/48、45/48；批后评分v2对同一响应零API重评为41/48、41/48、47/48。缺方向9/9正确追问，仍有1次成本目标改写错误追问。两版记录均保留。[证据](report/direction_explanation_regression_2026-10-16.md)。

v0.11.9加入图结构与目标证据路由，222项测试通过。定向42次原始34/42、格式后34/42、本地后39/42；原成本改写3/3正确拒绝。保留1项实际多余追问与2项评分边界失败，混合任务仍有拆分建议待精简。[证据](report/graph_routing_regression_2026-10-17.md)。

v0.11.10加入窄范围单边完整性证据、收紧混合拒绝说明并修正两项评分边界，230项测试通过。45次回归原始37/45、格式后37/45、本地后43/45；完整单边9/9通过。仍有2项方向追问失败及1项混合拒绝删目标建议漏检，原始统计保留。[证据](report/single_edge_regression_2026-10-17.md)。

## 当前阶段

自 `2026-10-16` 起，项目按用户确认的新目标转向 **跨题型数学建模与求解助手**，计划八周内交付约束优化、拟合预测、动态系统、图与网络四类能力。A1/A2 保留为前期资产，旧结项报告不是新助手的最终报告。

当前生效计划：[八周规划](report/modeling_assistant_plan_2026-10-16.md)。该计划替代旧计划“不扩大实验范围”的安排。

| 新主线 | 当前状态 |
|---|---|
| 20 个基础题族 | 已确定清单及 8 开发 / 12 保留测试划分，完整题面与评分器待建设 |
| 第一周生产计划 | 已实现离线模板建模、线性/整数求解、可行性检查、追加约束和报告导出 |
| 自由自然语言建模 | DeepSeek 已完成生产计划单题真实调用验收；其他题型与批量评价待完成 |
| OPT02 运输分配 | 已接入六路线建模、求解、独立评价及供给不足验证 |
| FIT01/FIT02 拟合预测 | 已接入线性标定、多项式训练内选阶、留出误差与独立复算 |
| DYN01/DYN02 动态系统 | 已接入牛顿冷却、Logistic 增长、数值积分和解析解对照 |
| NET01/NET02 图与网络 | 最短路径、最大流、最优性证据、独立评分及真实调用首轮通过 |
| 八题统一开发基线 | 单次真实批量自动评分8/8，说明文字1处警告；详见[基线记录](report/development_batch_baseline_2026-10-16.md) |
| 开发变体重复评测 | 24变体+8原题，各2次；离线复核62/64，发现K=0处理缺陷；[详情](report/development_variants_results_2026-10-16.md) |
| 参数修复与定向回归 | K=0澄清修复，在线9/10、本地数据7/7；发现天/小时换算波动；[详情](report/parameter_and_units_regression_2026-10-16.md) |
| 动态时间确定性换算 | 原值/单位/引用留存，本地转换；定向复核11/12，Logistic混合单位3/3；[详情](report/deterministic_units_regression_2026-10-16.md) |
| JSON受限格式修复 | 历史多字段失败重放通过；新一轮原schema与数值12/12；[详情](report/json_format_repair_regression_2026-10-16.md) |
| 最新定向回归 | v0.11.3：原始49/57、格式后49/57、本地后56/57；原11题子集27/33原始、33/33最终，187项测试；护栏未改，保留合法换算误拒绝；[详情](report/guard_causes_regression_2026-10-16.md) |
| 最近完整回归 | v0.11.2：原始90/101、格式后90/101、本地后101/101；176项测试，旧漏域题及4个新边界原始通过；仍有11项依赖本地策略；[详情](report/missing_capacity_full_regression_2026-10-16.md) |
| 上轮定向回归 | v0.11.1：三层均35/36；两项原失败各3/3原始通过，161项本地测试；另保留缺容量追问漏参数域1次失败；[详情](report/remaining_failures_regression_2026-10-16.md) |
| 历史89场景完整回归 | v0.11.0：原始82/89、格式后82/89、本地后87/89；146项测试通过，原道路单位问题已通过，仍有2项失败；[详情](report/graph_units_regression_2026-10-16.md) |
| 历史82场景回归 | v0.10.11：76/82→76/82→81/82；原道路单位失败保留；[详情](report/unified_82_regression_2026-10-16.md) |
| 正实数容量边界回归 | v0.10.1边界20/21，原失败题另测3/3；整数限制未复现，仍有1次多余确认；[详情](report/real_capacity_regression_2026-10-16.md) |
| 超容量初值与同义表达 | v0.10.2，12场景各3次原始36/36，修复/护栏新增0；本轮无多余确认；[详情](report/above_capacity_regression_2026-10-16.md) |
| 禁止改值同义表达 | 主批原始25/36、本地处理后34/36；补测4/6→6/6；对照误拦截0/27，冲突状态仍不一致；[详情](report/immutable_paraphrases_regression_2026-10-16.md) |
| 容量冲突先澄清 | 原始27/30、本地处理后30/30；冲突题15/15原始通过，对照误拦截0/15；仍有量纲追问警告；[详情](report/capacity_conflict_regression_2026-10-16.md) |
| 中立核对与量纲追问 | 原始37/39、本地处理后38/39；两项目标未复现，仍有1次数值等价记录被误判冲突；[详情](report/neutral_dimensions_regression_2026-10-16.md) |
| 数值等价记录 | 原始27/30、最终28/30；等价误判未复现，仍有原文引用与拒绝后建议改值问题；[详情](report/equivalent_numbers_regression_2026-10-16.md) |
| 引用与拒绝措辞修复 | 原始29/30、引用修复新增1、最终30/30；132项测试，历史失败重放通过；[详情](report/provenance_refusal_regression_2026-10-16.md) |
| 新对照实验 | 尚未开展；单模型开发基线与离线测试不替代正式对照 |

新入口：

- [助手使用说明](modeling_assistant/README.md)
- [题库与固定划分](report/modeling_assistant_task_bank_v1.md)
- [第一周进度](report/week1_production_progress_2026-10-16.md)
- [新版交付清单](report/modeling_assistant_delivery_checklist_v1.md)

在仓库根目录运行：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-assistant.txt
.venv/bin/python -m modeling_assistant --demo
```

## 前期 A1/A2 阶段资产

以下为本次重规划前的阶段快照。A1/A2 主案例、固定协议评估、bug-repair benchmark、A2 expanded-scope/fresh-generation 和 CLI 原型已经完成；结项报告、流程指南、答辩脚本和逐页 PPT 结构的 v0 初稿也已形成，剩余工作集中在导师审阅、图表排版、口头演练和最终提交 QA。

| 模块 | 当前状态 | 主要证据 |
|---|---|---|
| A1 Seam Carving | 已完成主案例闭环 | 12 条 guidance 记录、18 条性能记录、9 条 bug-repair 记录 |
| A2 低秩图像修复 | 已完成主案例闭环 | 15 条 guidance 记录、60 条恢复结果、9 条 bug-repair 记录、48 条 expanded-scope case 记录 |
| 题库 | 中期版已成型 | 16 个正式条目，按主案例、固定协议、expanded-scope 代表案例和 failure cases 分层 |
| A3 / A4 | 首发条目已冻结 | 已有 requirement 和 taskcard，尚未进入固定协议实验 |
| CLI 原型 | 可演示 | `run_research_case.py --demo advisor` |
| 状态检查 | 可复核 | `scripts/check_research_status.py` 只读检查 metrics 与 pilot 状态 |
| 小样本试用 | 暂缓正式招募 | 已完成 1 次内部 dry run；任务包已预建，但反馈显示当前任务前置知识要求较高，暂不把非专业参与者纳入正式对照 |
| 中期汇报 | 已整理 | [大研中期汇报.pptx](大研中期汇报.pptx) |
| 结项包 | v0 初稿已形成，待审阅和归档 | [report/closure_plan_2026-10-16.md](report/closure_plan_2026-10-16.md) |

## 前期 A1/A2 稳定结论

当前证据最稳妥支持两点：

1. 在 A1 / A2 的固定协议下，`plain_guidance` / `coe_guided` 的主要价值是提高过程可复查性，包括自检覆盖、根因说明和回归说明。
2. 在 A2 这类冻结协议的图像修复任务上，三种提示方式的最终恢复指标基本一致，因此不应写成“结构化 guidance 显著提高图像质量”。

换句话说，当前结论是“过程质量和可解释性提升”，不是“大样本教学效果已经被证明”。

## 证据链

一条完整实验记录大致按下面的链路组织：

```text
problems/ 或 task_cards/
  -> prompts/
  -> solutions/<case>/generated/<run>/
  -> outputs/<case>/<run>/
  -> metrics/*.csv
  -> runs/*.md
  -> report/*.md
```

其中：

- `solutions/` 保存代码产物、参考实现、模型生成版本和 failure cases。
- `outputs/` 保存运行后生成的图片、CSV、JSON 和评估摘要。
- `metrics/` 保存结构化评分表和 codebook。
- `runs/` 保存每次实验的叙事记录。
- `report/` 保存阶段总结、协议、题库索引、pilot 方案和中期收口材料。

## 任务主线

### A1: Seam Carving

A1 用接缝裁剪任务验证代码生成、固定协议复现和 bug repair。

常用入口：

- 任务要求：[problems/hw1_op1_requirement.md](problems/hw1_op1_requirement.md)
- 主任务卡：[task_cards/A1_seam_carving_taskcard_v1.md](task_cards/A1_seam_carving_taskcard_v1.md)
- bug-repair 任务卡：[task_cards/A1_bug_repair_taskcard_v0.md](task_cards/A1_bug_repair_taskcard_v0.md)
- 评测协议：[report/a1_eval_protocol_v0.md](report/a1_eval_protocol_v0.md)
- 阶段总结：[report/a1_v1_stage_summary.md](report/a1_v1_stage_summary.md)
- bug-repair 总结：[report/a1_bug_repair_summary_v0.md](report/a1_bug_repair_summary_v0.md)
- 指标表：[metrics/a1_guidance_eval_v0.csv](metrics/a1_guidance_eval_v0.csv), [metrics/a1_codegen_perf_v0.csv](metrics/a1_codegen_perf_v0.csv), [metrics/a1_failure_repair_eval_v0.csv](metrics/a1_failure_repair_eval_v0.csv)

### A2: 低秩图像修复

A2 从早期较宽的“SVD 图像压缩”方向，收束为低秩图像任务族下的灰度图像修复主案例：

`hw2-op2/src/chapter5_rslt.py::rslt_inpainting(...)`

常用入口：

- 任务要求：[problems/a2_requirement.md](problems/a2_requirement.md)
- 主任务卡：[task_cards/A2_rslt_inpainting_taskcard_v1.md](task_cards/A2_rslt_inpainting_taskcard_v1.md)
- bug-repair 任务卡：[task_cards/A2_bug_repair_taskcard_v0.md](task_cards/A2_bug_repair_taskcard_v0.md)
- 评测协议：[report/a2_eval_protocol_v0.md](report/a2_eval_protocol_v0.md)
- 复现实验总结：[report/a2_replication_summary_v0.md](report/a2_replication_summary_v0.md)
- expanded-scope 总结：[report/a2_expanded_scope_summary_v0.md](report/a2_expanded_scope_summary_v0.md)
- bug-repair 总结：[report/a2_bug_repair_summary_v0.md](report/a2_bug_repair_summary_v0.md)
- A2 工程说明：[hw2-op2/README.md](hw2-op2/README.md)
- 指标表：[metrics/a2_guidance_eval_v0.csv](metrics/a2_guidance_eval_v0.csv), [metrics/a2_recovery_perf_v0.csv](metrics/a2_recovery_perf_v0.csv), [metrics/a2_failure_repair_eval_v0.csv](metrics/a2_failure_repair_eval_v0.csv), [metrics/a2_expanded_scope_perf_v0.csv](metrics/a2_expanded_scope_perf_v0.csv)

### A3 / A4

A3 / A4 目前作为后续扩展入口，不支撑当前主结论。

- A3 曲线拟合：[problems/a3_requirement.md](problems/a3_requirement.md), [task_cards/A3_taskcard_v1.md](task_cards/A3_taskcard_v1.md)
- A4 Poisson 图像融合：[problems/a4_requirement.md](problems/a4_requirement.md), [task_cards/A4_taskcard_v1.md](task_cards/A4_taskcard_v1.md)

## 题库口径

当前中期题库按“主案例家族 / 固定协议与子任务 / failure cases”三层整理。

正式计入中期题库的条目共 16 个：

- A1：2 个主任务 + 3 个 failure cases
- A2：2 个 fixed protocol + 4 个 expanded-scope 代表案例 + 3 个 failure cases
- A3：1 个首发条目
- A4：1 个首发条目

注意：direct / plain guidance / CoE 的重复 rerun 是证据材料，不直接当成额外题库条目。

详见 [report/task_bank_index_v1.md](report/task_bank_index_v1.md) 和 [report/task_bank_status_v1.md](report/task_bank_status_v1.md)。

## Metrics 概览

| 文件 | 数据行数 | 用途 |
|---|---:|---|
| [metrics/a1_guidance_eval_v0.csv](metrics/a1_guidance_eval_v0.csv) | 12 | A1 prompt 模式下的 artifact / runnable / correct / self-check 评价 |
| [metrics/a1_codegen_perf_v0.csv](metrics/a1_codegen_perf_v0.csv) | 18 | A1 代码生成运行时间和输出状态 |
| [metrics/a1_failure_repair_eval_v0.csv](metrics/a1_failure_repair_eval_v0.csv) | 9 | A1 failure-case 修复评分 |
| [metrics/a2_guidance_eval_v0.csv](metrics/a2_guidance_eval_v0.csv) | 15 | A2 prompt 模式下的 artifact / runnable / correct / self-check 评价 |
| [metrics/a2_recovery_perf_v0.csv](metrics/a2_recovery_perf_v0.csv) | 60 | A2 fixed protocol 的 PSNR / SSIM / RSE / runtime |
| [metrics/a2_failure_repair_eval_v0.csv](metrics/a2_failure_repair_eval_v0.csv) | 9 | A2 failure-case 修复评分 |
| [metrics/a2_expanded_scope_eval_v0.csv](metrics/a2_expanded_scope_eval_v0.csv) | 3 | A2 expanded-scope 主记录 |
| [metrics/a2_expanded_scope_perf_v0.csv](metrics/a2_expanded_scope_perf_v0.csv) | 48 | A2 expanded-scope case 级恢复指标 |
| [metrics/pilot_session_log_dry_run_v0.csv](metrics/pilot_session_log_dry_run_v0.csv) | 1 | 内部 dry run 的 session 级记录 |
| [metrics/pilot_session_log_template_v0.csv](metrics/pilot_session_log_template_v0.csv) | 0 | formal pilot 暂缓，保留为后续模板 |

每个 CSV 的字段含义以同目录下的 `*_codebook_v0.md` 为准。

## Pilot 状态

小样本试用当前定位从“立即招募”调整为“内部可行性审查”。原因是当前 bug-repair 任务同时要求 Python 调试、算法理解、图像处理和代码阅读能力，直接招募非相关背景参与者会把前置知识差异和流程条件混在一起。

当前已完成：

- `2026-04-20` 内部 dry run：见 [report/pilot_internal_dry_run_result_2026-04-20.md](report/pilot_internal_dry_run_result_2026-04-20.md)
- dry run 记录：[pilot/dry_run_records/PILOT_20260420_000/](pilot/dry_run_records/PILOT_20260420_000/)
- 首轮 4 个 formal pilot task pack：[pilot/formal_pilot_task_packs/](pilot/formal_pilot_task_packs/)，可直接发放的汇总包：[pilot/formal_pilot_S01-S04_task_packs/](pilot/formal_pilot_S01-S04_task_packs/)；当前作为后续候选材料保留，不启动正式发放
- session log 模板：[metrics/pilot_session_log_template_v0.csv](metrics/pilot_session_log_template_v0.csv)
- 内部过程审查：[report/internal_process_audit_v0.md](report/internal_process_audit_v0.md)

正式受试者数据尚未采集，S01-S04 暂缓执行。原冻结分配仍保留作后续候选设计：

- S01：`T2_A1_bug_01` + `baseline_workflow`
- S02：`T2_A1_bug_01` + `process_guided_workflow`
- S03：`T3_A2_bug_01` + `baseline_workflow`
- S04：`T3_A2_bug_01` + `process_guided_workflow`

详见 [report/small_sample_pilot_plan_v0.md](report/small_sample_pilot_plan_v0.md)、[report/pilot_round1_schedule_v0.md](report/pilot_round1_schedule_v0.md) 和 [pilot/formal_pilot_task_packs/README.md](pilot/formal_pilot_task_packs/README.md)。

## 快速阅读顺序

如果只想快速理解当前项目，建议按这个顺序看：

1. [大研中期汇报.pptx](大研中期汇报.pptx)
2. [report/midterm_stage_summary_v0.md](report/midterm_stage_summary_v0.md)
3. [report/phase2_progress_report_2026-04-12.md](report/phase2_progress_report_2026-04-12.md)
4. [report/task_bank_index_v1.md](report/task_bank_index_v1.md)
5. [report/small_sample_pilot_plan_v0.md](report/small_sample_pilot_plan_v0.md)
6. [report/internal_process_audit_v0.md](report/internal_process_audit_v0.md)
7. [report/evidence_matrix_v0.md](report/evidence_matrix_v0.md)
8. [report/final_results_summary_v0.md](report/final_results_summary_v0.md)
9. [report/final_report_outline_v0.md](report/final_report_outline_v0.md)
10. [report/closure_plan_2026-10-16.md](report/closure_plan_2026-10-16.md)
11. [report/final_submission_checklist_v0.md](report/final_submission_checklist_v0.md)
12. [report/pilot_internal_dry_run_result_2026-04-20.md](report/pilot_internal_dry_run_result_2026-04-20.md)

结项新增入口：

- [report/final_workflow_guide_v0.md](report/final_workflow_guide_v0.md)：从题库、Task Card、prompt 到 run、metrics 和结论的完整流程。
- [report/final_report_v0.md](report/final_report_v0.md)：结项报告正文 v0。
- [report/defense_script_v0.md](report/defense_script_v0.md)：五分钟演示脚本和常见追问口径。

早期规划和参考附件集中放在 [Other/](Other/)：

- [Other/TimeLine.docx](Other/TimeLine.docx)
- [Other/talktoai.pdf](Other/talktoai.pdf)
- [Other/大研课题规划建议.pdf](Other/大研课题规划建议.pdf)
- [Other/中期研究小白讲透版.pdf](Other/中期研究小白讲透版.pdf)

## CLI 原型

当前有一个最小命令行入口，用来串起题目、任务卡、prompt、run 文档和 metrics 摘要。

```bash
python3 run_research_case.py --list
python3 run_research_case.py --demo advisor
python3 run_research_case.py --case A1 --mode plain_guidance --track baseline
python3 run_research_case.py --case A2 --mode coe_guided --track bug-repair
python3 run_research_case.py --case A2 --mode direct_answer --track expanded-scope
python3 run_research_case.py --case A2 --mode plain_guidance --track fresh-generation
```

说明文档：[report/prototype_cli_v0.md](report/prototype_cli_v0.md) 和 [report/advisor_demo_entry_v1.md](report/advisor_demo_entry_v1.md)。

## 仓库结构

| 路径 | 内容 |
|---|---|
| [problems/](problems/) | 原始题目要求和 A2/A3/A4 requirement |
| [task_cards/](task_cards/) | 主任务卡和 bug-repair task card |
| [prompts/](prompts/) | A1 / A2 的 direct_answer、plain_guidance、CoE prompt |
| [runs/](runs/) | 每次实验的运行记录，共 66 份 run / queue / template 文档 |
| [metrics/](metrics/) | 结构化指标表和 codebook |
| [report/](report/) | 协议、阶段总结、中期材料、题库、pilot 方案 |
| [pilot/](pilot/) | 小样本试用表单、评分表、dry run 记录和 formal task packs |
| [solutions/](solutions/) | A1 / A2 的参考实现、模型生成代码和 failure cases；不放运行输出 |
| [outputs/](outputs/) | A1 / A2 每次运行生成的图片、CSV、JSON 和评估摘要；不放源代码 |
| [hw2-op2/](hw2-op2/) | A2 低秩图像修复项目本体，`src/chapter5_rslt.py` 是 A2 主案例 gold reference |
| [Other/](Other/) | 早期规划、导师沟通材料和辅助说明附件 |

`solutions/`、`outputs/`、`hw2-op2/` 各自有目录 README，新增文件优先按这些入口说明归档。

## 复现入口

研究状态检查：

```bash
python3 scripts/check_research_status.py
```

该命令只读检查 metrics 行数、关键字段、模式级结果和 formal pilot 状态，不重新运行模型或覆盖实验产物。

A1 复现：

```bash
python3 solutions/hw1_op1/src/run_step6_comparisons.py
python3 solutions/hw1_op1/generated/run_015_plain_guidance_rep3/src/run_protocol_eval.py
```

A2 项目：

```bash
cd hw2-op2
python3 run_all.py
python3 gui.py
```

依赖以各目录中的 `requirements.txt` / `environment.yml` 为准。当前主实验记录中使用的 conda 环境名是 `llmft`。

## 下一步

1. [第一周收尾与OPT02接入](report/week1_completion_and_transport_2026-10-16.md)已完成首轮开发验收，包括连续澄清、整数边界和运输分配。
2. 四类八个开发题已接通；82场景统一回归完成，下一步优先修复图边权单位换算，保留原始数值与单位。
3. 按 [八周规划](report/modeling_assistant_plan_2026-10-16.md) 推进四类能力及独立测试，先用开发集估算 API 成本。

A1/A2 原结项文档保留作前期材料，最终提交以新版交付清单为准。
