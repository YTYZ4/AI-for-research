# Pilot Bug Repair Checklist v0

## 目的
给 `process_guided_workflow` 条件下的参与者一张最小可执行检查单，避免把完整协议文档直接塞给参与者，也避免过程化条件只停留在口头提醒。

## 使用方式
- 适用任务：`T2_A1_bug_01`、`T3_A2_bug_01`
- 适用条件：`process_guided_workflow`
- 建议在开始编码前先过一遍，在提交前再回看一遍。

## 最小流程
1. 先用一句话重述当前 symptom。
2. 写清楚“理想行为”应该是什么。
3. 写出当前最可能被破坏的关键不变量。
4. 只修改与主错误直接相关的代码。
5. 提交前至少做一次自检和一次最小回归说明。

## 提交前检查
- 我是否明确指出了主错误，而不是只复述表面报错？
- 我的 patch 是否保持原函数名、参数和返回约定？
- 我是否避免了为过当前 case 而重写整段逻辑？
- 我是否写清楚了修补后为什么不容易复发？

## A1 额外提醒
- 边界列只允许读取合法父节点。
- 不要因为修 `bug_01` 顺手改坏 shape / transpose 语义。

## A2 额外提醒
- `mask > 0.5` 表示观测像素，这个语义不能反。
- 观测区约束和低秩分量回写不能丢。

## 交付物提醒
- final submission：按 `pilot/pilot_participant_submission_template_v0.md` 留下 diagnosis、最终代码路径和 regression notes
- patched code：最小修补版本
- 若是 `process_guided_workflow`，notes template 保留过程痕迹，不替代最终 submission
