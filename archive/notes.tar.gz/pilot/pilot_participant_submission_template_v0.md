# Pilot 结果提交表

任务结束时请填写本表。即使代码没有完全修好，也请说明你的判断、当前代码位置和卡住点。

## 基本信息
- `session_id`：
- `participant_id`：
- 日期：
- `task_id`：
- `condition`：`baseline_workflow / process_guided_workflow`
- `session_stage`：`internal_dry_run / formal_pilot`

## 1. 错误诊断（diagnosis）
- 我认为主错误 / 关键问题是：
- 简短原因说明：

## 2. 最终代码（final submission）
- 最终提交代码路径 / 文件名：
- 若代码还不能完整运行，当前卡住点是：
- 我本次没有改动的部分：

## 3. 最小检查与回归说明（regression notes）
- 我实际做过的最小检查：
- 若还有时间，我下一步会补哪条检查：
