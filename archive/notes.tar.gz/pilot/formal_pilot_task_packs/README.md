# Formal Pilot Task Packs

## 目的
把首轮 `4` 个 formal pilot session 的 participant-visible 材料和 researcher-only 材料提前拆成独立文件夹，避免正式执行时临时拣文件、混发 scorer-only 材料。

## 当前状态
- 已预建 `S01` 到 `S04` 四个独立 task pack 文件夹。
- 已额外整理出可直接发放给参与者的简化目录：
  - `S01/`
  - `S02/`
  - `S03/`
  - `S04/`
- 每个 task pack 都拆成：
  - `participant_pack/`
  - `researcher_pack/`
  - `records/`
- 当前已冻结的是任务顺序和 task pack。
- `session_id`、日期、时间仍待按真实招募结果回填，不在仓库里虚填。
- 由于当前任务对 Python 调试、算法理解、图像处理和代码阅读有较高要求，S01-S04 当前暂缓发放；这些目录保留为后续候选材料，不是已执行样本。

## 目录说明
- `S01/` 到 `S04/`
  - 这是“直接发给参与者”的简化目录。
  - 里面只保留 participant-visible 文件，不含 researcher-only 材料。
- `S01_T2_A1_bug_01_baseline_workflow/`
  - 对应 `P01`
  - 任务：`T2_A1_bug_01`
  - 条件：`baseline_workflow`
- `S02_T2_A1_bug_01_process_guided_workflow/`
  - 对应 `P02`
  - 任务：`T2_A1_bug_01`
  - 条件：`process_guided_workflow`
- `S03_T3_A2_bug_01_baseline_workflow/`
  - 对应 `P03`
  - 任务：`T3_A2_bug_01`
  - 条件：`baseline_workflow`
- `S04_T3_A2_bug_01_process_guided_workflow/`
  - 对应 `P04`
  - 任务：`T3_A2_bug_01`
  - 条件：`process_guided_workflow`

## 使用方式
- 可直接发放的汇总目录是 `pilot/formal_pilot_S01-S04_task_packs/`，压缩包是 `pilot/formal_pilot_S01-S04_task_packs.zip`。
- 若你只想分别发材料给参与者，就从汇总目录中取对应的 `S01/` 到 `S04/`；不要把四个文件夹一起发给同一个人。
- 若你还要同时保留研究者侧材料与回收目录，就继续使用长名字目录下的 `participant_pack/`、`researcher_pack/` 和 `records/`。
- `researcher_pack/` 只留给研究者，不向参与者发放。
- 执行结束后，把回收表单、代码、评分和验证产物放回对应 `records/`。
- 若线下执行需要压缩包，可直接按 session 目录打包，不再临时拼材料。
- 在恢复正式 pilot 前，应先用更低前置知识要求的任务做一次可行性测试。

## 严禁混入 participant pack 的材料
- `diagnosis.md`
- `fixed_code.py`
- 既有 `patched_code.py`
- `prompt_used.md`
- `model_raw_response.md`

## AI 使用与结果分析（研究者）

本轮只有 `4` 个 session，不能把 AI 使用当作普通噪声后再用统计方法“控制掉”。如果 S01–S04 的 AI 使用不一致，完成时间、代码正确性、诊断质量和过程记录都可能同时被影响，baseline 与 process-guided 的差异就不再能单独归因于材料条件。

建议本轮默认采用：**禁止外部生成式 AI**。如果研究问题本来就是“人 + AI”协作，则四个人必须统一工具、模型、可用环节和记录方式，并保存完整对话；不能让一部分人自由使用、另一部分人不用。

无论采用哪种规则，都要在 participant form、session record 和 CSV 中记录：`ai_policy`、`ai_used`、`ai_tool`、`ai_use_scope`、`ai_transcript_path`。若有人违规或漏记，不要删除该 session，而是在 notes 中标记，并在分析中把它作为探索性结果或敏感性比较。
