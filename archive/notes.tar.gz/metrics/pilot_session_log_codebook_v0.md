# pilot session log codebook v0

适用范围：
- `metrics/pilot_session_log_template_v0.csv`
- 后续小样本试用的 session 级结构化记录

目标：
- 先把 baseline vs 过程化流程的小样本试用数据结构固定下来，避免首轮试用后再倒推字段。

## 字段定义与取值

### session_id
- 建议格式：`PILOT_YYYYMMDD_001`

### date
- 建议格式：`YYYY-MM-DD`

### participant_id
- 匿名编号，例如：`P01`

### task_id
- 当前冻结任务池：
  - `T1_A1_width`
  - `T2_A1_bug_01`
  - `T3_A2_bug_01`

### condition
- 允许值：
  - `baseline_workflow`
  - `process_guided_workflow`

### session_stage
- 允许值：
  - `internal_dry_run`
  - `formal_pilot`
- 内部 dry run 建议保留记录，但后续汇总正式 pilot 时应先过滤掉 `internal_dry_run`

### task_type
- 允许值：
  - `implementation`
  - `bug_repair`

### scorer_id
- 评分者或记录者编号

### python_bg / numpy_bg / debugging_bg / image_task_bg
- `1` 到 `5`
- `1` = 非常不熟悉
- `5` = 非常熟悉

### prior_similar_task
- `0` = 没做过类似任务
- `1` = 做过相近任务

### prior_repo_exposure
- `0` = 未提前看过本仓库材料
- `1` = 提前看过

### ai_policy
- 本次 session 事先规定的 AI 使用规则：
  - `prohibited`：不得使用外部生成式 AI
  - `standardized`：允许使用研究者指定的同一工具、模型和操作规则
  - `unrestricted_logged`：可以自由使用，但必须完整记录
- 历史记录无法追溯时可填 `NA`，正式 pilot 不应使用 `NA`

### ai_used
- `0` = 未使用生成式 AI
- `1` = 使用过生成式 AI
- `uncertain` = 研究者无法确认

### ai_tool
- 实际使用的产品和模型，例如 `ChatGPT / GPT-5`；未使用时填 `NA`

### ai_use_scope
- 可用 `|` 分隔多个环节：
  - `task_understanding`
  - `diagnosis`
  - `code_generation`
  - `debugging`
  - `writeup`
  - `other`
- 未使用时填 `NA`

### ai_transcript_path
- AI 对话记录的相对路径或链接；未使用时填 `NA`

### completion_status
- `0 / 1 / 2`
- 含义见：`pilot/pilot_scoring_sheet_v0.md`

### runnable
- `0 / 1`

### outcome_quality
- `0 / 1 / 2`

### self_check_coverage
- `0 / 1 / 2`

### root_cause_explanation
- `0 / 1 / 2 / NA`
- 对 implementation 任务若不适用，可填 `NA`

### regression_plan_quality
- `0 / 1 / 2`

### artifact_completeness
- `0 / 1 / 2`

### time_to_first_working_min
- 单位：分钟
- 若无可运行结果，可填 `NA`

### total_session_min
- 单位：分钟

### help_request_count
- 非负整数

### task_clarity_rating / process_clarity_rating / confidence_rating / cognitive_load_rating / reuse_intent_rating
- `1` 到 `5`
- `cognitive_load_rating` 取值越高表示主观负担越重

### notes
- 简短补充说明：
  - 卡点
  - 研究者介入
  - 特殊情况
  - AI 使用规则偏离、对话缺失或疑似未披露等情况

### artifact_paths
- 记录相对路径，建议至少包含：
  - `participant_form`
  - `participant_submission`
  - 最终代码文件
  - `scoring_sheet`
- 若有 `process_guided_workflow` 的 notes、`session_record`、验证脚本或输出，也一并写入

## 填表规则
- 先保留原始表单和 session record，再回填 CSV。
- 同一 session 只保留一行主记录。
- 评分相关字段以 `pilot/pilot_scoring_sheet_v0.md` 为准；`session_record` 主要保留过程观察、介入说明和回填备注。
- 如果某个评分项不适用，不要留空，统一填 `NA`。
