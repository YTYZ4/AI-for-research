#!/usr/bin/env python3
"""Check the frozen A1/A2 evidence package and current pilot state."""

from __future__ import annotations

import csv
import sys
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

EXPECTED_ROWS = {
    "metrics/a1_guidance_eval_v0.csv": 12,
    "metrics/a1_codegen_perf_v0.csv": 18,
    "metrics/a1_failure_repair_eval_v0.csv": 9,
    "metrics/a2_guidance_eval_v0.csv": 15,
    "metrics/a2_recovery_perf_v0.csv": 60,
    "metrics/a2_failure_repair_eval_v0.csv": 9,
    "metrics/a2_expanded_scope_eval_v0.csv": 3,
    "metrics/a2_expanded_scope_perf_v0.csv": 48,
    "metrics/pilot_session_log_dry_run_v0.csv": 1,
    "metrics/pilot_session_log_template_v0.csv": 0,
}


def read_csv(relative_path: str) -> tuple[list[str], list[dict[str, str]]]:
    path = ROOT / relative_path
    if not path.exists():
        raise ValueError(f"missing file: {relative_path}")
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise ValueError(f"missing header: {relative_path}")
        return list(reader.fieldnames), list(reader)


def require_columns(relative_path: str, columns: set[str]) -> list[dict[str, str]]:
    fieldnames, rows = read_csv(relative_path)
    missing = columns.difference(fieldnames)
    if missing:
        raise ValueError(f"{relative_path}: missing columns {sorted(missing)}")
    return rows


def count_by_mode(rows: list[dict[str, str]], value_column: str, target: str) -> dict[str, tuple[int, int]]:
    counts: defaultdict[str, list[int]] = defaultdict(lambda: [0, 0])
    for row in rows:
        mode = row["mode"]
        counts[mode][0] += 1
        if row[value_column] == target:
            counts[mode][1] += 1
    return {mode: (total, matched) for mode, (total, matched) in sorted(counts.items())}


def print_metric_summary(case: str, relative_path: str, rows: list[dict[str, str]]) -> None:
    correct = count_by_mode(rows, "correct", "2")
    self_check = count_by_mode(rows, "self_check", "2")
    print(f"{case} guidance: {relative_path}")
    for mode in sorted(correct):
        total, correct_count = correct[mode]
        _, self_check_count = self_check[mode]
        print(f"  {mode}: n={total}, correct=2 {correct_count}/{total}, self_check=2 {self_check_count}/{total}")


def print_bug_summary(case: str, relative_path: str, rows: list[dict[str, str]]) -> None:
    print(f"{case} bug-repair: {relative_path}")
    by_mode: defaultdict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        by_mode[row["mode"]].append(row)
    for mode in sorted(by_mode):
        mode_rows = by_mode[mode]
        diagnosis = sum(row["diagnosis_correct"] == "1" for row in mode_rows)
        patch = sum(row["patch_runnable"] == "1" for row in mode_rows)
        regression = sum(row["regression_pass"] == "1" for row in mode_rows)
        print(
            f"  {mode}: n={len(mode_rows)}, diagnosis={diagnosis}/{len(mode_rows)}, "
            f"patch={patch}/{len(mode_rows)}, regression={regression}/{len(mode_rows)}"
        )


def main() -> int:
    errors: list[str] = []
    loaded: dict[str, list[dict[str, str]]] = {}

    for relative_path, expected_rows in EXPECTED_ROWS.items():
        try:
            _, rows = read_csv(relative_path)
            loaded[relative_path] = rows
            if len(rows) != expected_rows:
                errors.append(f"{relative_path}: expected {expected_rows} data rows, found {len(rows)}")
        except ValueError as exc:
            errors.append(str(exc))

    try:
        a1_guidance = require_columns("metrics/a1_guidance_eval_v0.csv", {"mode", "correct", "self_check"})
        a2_guidance = require_columns("metrics/a2_guidance_eval_v0.csv", {"mode", "correct", "self_check"})
        a1_bugs = require_columns(
            "metrics/a1_failure_repair_eval_v0.csv",
            {"mode", "diagnosis_correct", "patch_runnable", "regression_pass"},
        )
        a2_bugs = require_columns(
            "metrics/a2_failure_repair_eval_v0.csv",
            {"mode", "diagnosis_correct", "patch_runnable", "regression_pass"},
        )
        print_metric_summary("A1", "metrics/a1_guidance_eval_v0.csv", a1_guidance)
        print_metric_summary("A2", "metrics/a2_guidance_eval_v0.csv", a2_guidance)
        print_bug_summary("A1", "metrics/a1_failure_repair_eval_v0.csv", a1_bugs)
        print_bug_summary("A2", "metrics/a2_failure_repair_eval_v0.csv", a2_bugs)
    except ValueError as exc:
        errors.append(str(exc))

    dry_run = loaded.get("metrics/pilot_session_log_dry_run_v0.csv", [])
    template = loaded.get("metrics/pilot_session_log_template_v0.csv", [])
    formal_rows = [row for row in dry_run if row.get("session_stage") == "formal_pilot"]
    unexpected_stages = [row.get("session_stage") for row in dry_run if row.get("session_stage") != "internal_dry_run"]
    print("Pilot state:")
    print(f"  internal_dry_run rows: {len(dry_run)}")
    print(f"  formal_pilot rows: {len(formal_rows)}")
    print(f"  formal template rows: {len(template)}")
    if formal_rows:
        errors.append("pilot_session_log_dry_run_v0.csv contains formal_pilot rows while formal pilot is paused")
    if unexpected_stages:
        errors.append(f"pilot_session_log_dry_run_v0.csv has unexpected session_stage values: {unexpected_stages}")

    for relative_path in (
        "report/internal_process_audit_v0.md",
        "report/evidence_matrix_v0.md",
        "run_research_case.py",
        "pilot/formal_pilot_S01-S04_task_packs.zip",
    ):
        if not (ROOT / relative_path).exists():
            errors.append(f"missing required project asset: {relative_path}")

    if errors:
        print("STATUS: FAIL")
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1

    print("Evidence row counts: PASS")
    print("STATUS: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
